/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Calculate Paycheck
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float hrsWrkd,//Hours worked (hrs)
            payrate,//Payrate in $'s/hr
            payChck;//Paycheck in $'s

    //Input or initialize values Here
    cout<<"This program calculates your paycheck"<<endl;
    cout<<"Your hours worked and payrate are required"<<endl;
    cout<<"Input your hours worked in hours"<<endl;
    cin>>hrsWrkd;
    cout<<"Input your payrate in $'s/hr"<<endl;
    cin>>payrate;
    
    //Process/Calculations Here
    payChck=payrate*hrsWrkd;
            
    //Output Located Here
    cout<<"Your Pay check = $"<< payChck<<endl;

    //Exit
    return 0;
}

