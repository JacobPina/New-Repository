/* 
 * File:   main.cpp
 * Author: Jacob N.Piña
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  C++ Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables



//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    unsigned char stkPrce=35;   // Units of dollars per share
    unsigned short nShares=750; // number of shares
    float comishn=2.0e-2f;    //commission
    unsigned short stkPaid,comPaid,totPaid;
    //Input or initialize values Here
    
    //Process/Calculations Here
    stkPaid=stkPrce*nShares;
    comPaid=stkPaid*comishn;
    totPaid=stkPaid+comPaid;
    //Output Located Here
    cout<<"Stock Price per Share=$"<<static_cast<int>(stkPrce)<<"/share"<<endl;
    cout<<"Number of Shares     ="<<nShares<<"shares"<<endl;
    cout<<"Commission           ="<<comishn<<endl;
    cout<<"Stock Price Paid     = $"<<stkPaid<<endl;
    cout<<"Commission Paid      = $"<<comPaid<<endl;
    cout<<"Total Paid           = $"<<totPaid<<endl;
    //Exit
    return 0;
}

