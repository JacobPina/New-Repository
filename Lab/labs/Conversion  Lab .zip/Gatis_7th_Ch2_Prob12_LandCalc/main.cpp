/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 4, 2017, 1:00 PM
 * Purpose:  C++ Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
const int CNVACFT= 47560;

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int nAcres,nFt2;
    //Input or initialize values Here
    cout<<"This is a conversion program"<<endl;
    cout<<"Input number of acres"<<endl;
    cin>>nAcres;
    //Process/Calculations Here
    nFt2=nAcres*CNVACFT;
    //Output Located Here
    cout<<"The number of acres input = "<<nAcres<<endl;
    cout<<"Equivalent to"<<nFt2<<"ft squared"<<endl;

    //Exit
    return 0;
}

