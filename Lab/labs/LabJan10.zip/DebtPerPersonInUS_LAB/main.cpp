/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  This Program Finds the debt per person depending on the year 
 *          given the debt of the U.S. and the amount of people that 
 *          live in the U.S.\
 * //Source: http://www.usdebtclock.org/
 *           http://www.census.gov/popclock/
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float dbt08,dbt16;      //National Debt in 2008 and 2016
    float dbtPP08,dbtPP16;  //National Debt per person in 2008 and 2016
    float popUS08,popUS16;  //Population of the united states in 2008 and 2016
    
    //Input or initialize values Here
    dbt08=10.1e12;          //Debt in $s
    dbt16=19.5e12;
    popUS08=304e6;         
    popUS16=320e6;
    //Process/Calculations Here
    dbtPP08=dbt08/popUS08;  //Calculates the debt per person in $s
    dbtPP16=dbt16/popUS16;
    
    //Output Located Here
    cout<<"In 2008 the US debt was at $"<<dbt08<<endl;
    cout<<"In 2016 the US debt was at $"<<dbt16<<endl;
    cout<<"In 2008 the US population was "<<popUS08<<endl;  
    cout<<"In 2016 the US population was "<<popUS16<<endl;
    cout<<"This meant that the Debt/Person was $"<<dbtPP08<<" in 2008"<<endl;
    cout<<"And that the Debt/Person grew to    $"<<dbtPP16<<" in 2016"<<endl;
    

    //Exit
    return 0;
}

