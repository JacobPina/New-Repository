/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  This program tells what percentage of the federal budget goes to 
 *              NASA and the Military.
 * sources: https://www.nationalpriorities.org/campaigns/federal-budget-101/?gclid=CNbc1OjBuNECFRKXfgod1VsPxg
 *          https://www.nationalpriorities.org/campaigns/military-spending-united-states/
 *          https://en.wikipedia.org/wiki/Budget_of_NASA
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float fedBugt,nasaB,miltryB;// Federal budget, nasa budget, and military budget
    float prcntN,prcntM; //Percent of budget that goes to Nasa and Military
    
    //Input or initialize values Here
    fedBugt=3.54e12;
    miltryB=609e9;
    nasaB=19e9;
            
    //Process/Calculations Here
    prcntN=(nasaB/fedBugt)*100;
    prcntM=(miltryB/fedBugt)*100;
    
    
    //Output Located Here
    cout<<"The total federal budget is = $"<<fedBugt<<endl;
    cout<<"Nasa's Budget is equal to  = $"<<nasaB<<endl;
    cout<<"and the military budget is = $"<<miltryB<<endl;
    cout<<"That means that Nasa's budget is %"<<prcntN<<" of the federal budget"<<endl;
    cout<<"And that the military budget is %"<<prcntM<<" of the federal budget"<<endl;

    //Exit
    return 0;
}

