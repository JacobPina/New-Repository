/* 
 * File:   main.cpp
 * Author: Jacob N.Piña 
 * Created on January 3, 2017, 12:16 PM
 * Purpose: First Program Hello World
 */
//System Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants
// Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to another

//Function Prototypes

//Executable code begins here!
int main(int argc, char** argv) {
    //Declare variables
    
    //Input Values
    
    //Process by mapping inputs to outputs
    
    //Output  Values 
    cout<<"Hello World"<<endl;
    
    //Exit Stage
    return 0;
}

