/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 2, 2017, 12:07 PM
 * Purpose:  Calculates the costs depending if the patient is an 
 *              in-patient or an out-patient.Questions are not the same for 
 *              both s costs could be quite different
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
float inP(int,float,float,float);
float outP(float,float);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int inOrOut,nDays;//In-Patient or Out-Patient, number of days stayed
    float dayRate,medFees,serFees;//daily rate, medicine fees, service fees
    
    
    //Input or initialize values Here
    cout<<"This Program will ask if you are an in-Patient or an "
            "out-Patient"<<endl;
    cout<<"and then it will ask you questions depending on which you choose "
            "and then it will tell you how much you owe the hospital"<<endl;
    cout<<"Were you admitted as in-Patient or an out-Patient"<<endl;
    cout<<"Enter 0 if you are an in-Patient and 1 if you"
            " are an out-Patient"<<endl;
    cin>>inOrOut;
    while (inOrOut!=0&&inOrOut!=1){
        cout<<"Not a valid answer please enter 0 or 1"<<endl;
        cin>>inOrOut;
    }
    if (inOrOut==0){
        cout<<"How many days did you spend in the Hospital?"<<endl;
        cin>>nDays;
        cout<<"What was the daily rate in $'s of staying in th Hospital?"<<endl;
        cin>>dayRate;
        cout<<"What were the charges in $'s for the medication given?"<<endl;
        cin>>medFees;
        cout<<"What were the charges in $'s for the hospital services "
                "such as labs, tests, etc.?"<<endl;
        cin>>serFees;
        
        cout<<"The total in-Patient costs are = $"<<
                inP(nDays,dayRate,medFees,serFees)<<endl;
    }
    if (inOrOut==1){
        cout<<"What were the charges in $'s for the medication given?"<<endl;
        cin>>medFees;
        cout<<"What were the charges in $'s for the hospital services "
                "such as labs, tests, etc.?"<<endl;
        cin>>serFees;        
        
        cout<<"The total out-Patient costs are = $"<<
                outP(medFees,serFees)<<endl;
    }

    //Exit
    return 0;
}

float inP(int nDays,float dayRate,float medFees,float serFees){
    return (nDays*dayRate)+medFees+serFees;
}
float outP(float medFees,float serFees){
    return medFees+serFees;    
}

