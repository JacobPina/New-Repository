/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017, 8:30 PM
 * Purpose:  This program will flip a coin as many times as the user wants
 *               and will output the results 
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void coinFlp(float);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    unsigned int nThrows;
    
    //Input
    cout<<"This program will flip a coin as many times as you want and "
            "display the results"<<endl;
    cout<<"How many coin flips do you want"<<endl;
    cin>>nThrows;
    
    //Output Located Here

    coinFlp(nThrows);

    
    //Exit
    return 0;
}
void coinFlp(float nThrows){
    unsigned int  heads=1,tails=2,hcount=0,tcount=0;
     
    for (int i=1;i<=nThrows;i++){
    unsigned int flip=(rand()%2)+1;
    
    if (flip==heads){
        hcount++;
    }
    else if (flip==tails){
        tcount++;
    }
    }
    cout<<"Heads came up "<<hcount<<" times"<<endl;
    cout<<"Tails came up "<<tcount<<" times"<<endl;
    
}

