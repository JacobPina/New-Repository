/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017, 7:00 PM
 * Purpose:  This program will ask for the mass of an object in kg and 
                its velocity in meters per second and it will tell 
                you its kinetic energy
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void kEnergy(float);

//Program Execution Begins Here
int main(int argc, char** argv) {
  
    //Declare all Variables Here
    float KinEngy;//Kinetic Energy

    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"This program will ask for the mass of an object in kg and "
            "its velocity in meters per second and it will tell "
            "you its kinetic energy"<<endl;
    kEnergy(KinEngy);
 
    //Exit
    return 0;
}
void kEnergy(float KinEngy){
    float mass;//Mass of object
    float vel;//Velocity of object
    float KE;//Kinetic Energy
    cout<<"What is the mass of the object?"<<endl;
    cin>>mass;
    cout<<"What is the velocity of the object?"<<endl;
    cin>>vel;
    KE=.5*mass*(vel*vel);//Kinetic Energy calculations
    cout<<"The kinetic energy of the object is "<<KE<<endl;
}

