/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017, 1:37 PM
 * Purpose:  This program will ask for the amount of time an object has fallen
             and it will tell you how far it actually fell in meters 
 *           after every second
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
float g=9.8;//in meters/sec

//Function Prototypes Here
void disFall(float);

//Program Execution Begins Here
int main(int argc, char** argv) {
  
    //Declare all Variables Here
    float distance;

    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"This program will ask for the amount of time an object has fallen"
            " and it will tell you how far it actually fell in meters"
            " after every second"<<endl;
    disFall(distance);
 
    //Exit
    return 0;
}
void disFall(float distance){
    float time;//How long it fell
    float d;//How far it fell;
    cout<<"How long did the object fall in seconds?"<<endl;
    cin>>time;
    for (int i=1;i<=time;i++){
        d=.5*g*(i*i);
        cout<<"At "<<i<<" second(s) the object fell "<<
                d<<" meters"<<endl;
    }
}

