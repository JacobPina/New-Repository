/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017 12:21 PM
 * Purpose:  Finds the best sales division when the user enters
 *               their sales for the quarter
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
float getsale(float&);
void  fndHigh(float,float,float,float); 

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float NE;//North East
    float SE;//South East
    float NW;//North West
    float SW;//South West
    
    //Process/Calculations Here
    cout<<"Input the North East sales for the last quarter in $"<<endl;
    cout<<getsale(NE)<<endl;
    cout<<"Input the South East sales for the last quarter in $"<<endl;
    cout<<getsale(SE)<<endl;
    cout<<"Input the North West sales for the last quarter in $"<<endl;
    cout<<getsale(NW)<<endl;
    cout<<"Input the South West sales for the last quarter in $"<<endl;
    cout<<getsale(SW)<<endl;
    cout<<endl<<endl;
            fndHigh (NE,SE,NW,SW);
        
    //Exit
    return 0;
}

float getsale(float & num){
    do {
    cin>>num;
    if(num<0){cout<<"sorry no negative numbers allowed"<<endl;}
    }while (num<0.00);
    cout<<"$";
    return num;
}
void  fndHigh(float NE,float SE,float NW,float SW){
    const char *who="The North East";
    float high=NE;
    if(SE>high){
        who="The South East";
        high==SE;
    }
    if(NW>high){
        who="The North West";
        high=NW;
    }
    if(SW>high){
        who="The South West";
        high=SW;
    }
    cout<<who<<" had the highest sales with $"<<high<<endl;
    
}

