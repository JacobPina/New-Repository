/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 2, 2017, 12:47 PM
 * Purpose:  Enter a number and the program will tell you if it is prime
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
int isPrime(unsigned int);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    unsigned int num;
    
    //Input or initialize values Here
    cout<<"Enter any positive number greater than 0 and the program"
            " will tell you if it is prime"<<endl;
    cin>>num;
    while (num<1){
        cout<<"Can't accept that number please enter another"<<endl;
        cin>>num;
    }
    
    isPrime(num);
    
    //Exit
    return 0;
}

int isPrime(unsigned int num){
    int counter=0;
    int div;
    for (int i=2;i<num;i++){
        div=num%i;
        if (div==0){counter++;}
    }
    if (counter==0){
        cout<<num<<" is a prime number"<<endl;
    }
    if (counter>=1){
        cout<<num<<" is not a prime number"<<endl;
    }
}

