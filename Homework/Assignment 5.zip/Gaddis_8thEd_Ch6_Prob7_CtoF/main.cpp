/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017, 8:30 PM
 * Purpose:  Enter any temperature in Celsius and this program will convert it
            and the next 20 degrees to Fahrenheit
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void tempCon(float);

//Program Execution Begins Here
int main(int argc, char** argv) {
  
    //Declare all Variables Here
    float CtoF;//Kinetic Energy
    
    //Output Located Here
    tempCon(CtoF);
 
    //Exit
    return 0;
}
void tempCon(float CtoF){
    float C,i,F;//Celsius and Fahrenheit 
    
    //Input values
    cout<<"Enter any temperature in Celsius and this program will convert it"
            "and the next 20 degrees to Fahrenheit"<<endl;
    cout<<"What temperature in Celsius would you like to start with"<<endl;
    cin>>C;
    i=C;//Used for loop
    cout<<"Temperature in:"<<endl;
    cout<<"C                    F"<<endl;
    cout<<"_______________________"<<endl;
    
    //Process by mapping inputs to outputs
    for (i;i<=C+20;i++){//Outputs initial conversion an next 20
        F=i*(1.8)+32;
        
        cout<<setw(2)<<i<<"               "<<setw(4)<<F<<endl;
    }
}

