/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on Feb 2, 2017, 6:10 PM
  Purpose:  Menu to be used in Homework ASSIGNMENT 5
 */

//System Libraries
#include <iostream>//Input Output Library-
#include <iomanip> //Format Library-
using namespace std;

//User Libraries

//Global Constants
float g=9.8;//in meters/sec
int PERCENT=100;//Used for percentage conversions
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to another

//Function Prototypes
void calRetl (float,float);
float getsale(float&);
void  fndHigh(float,float,float,float); 
int Acident(int&);
void  fndLow(int,int,int,int,int); 
void disFall(float);
void kEnergy(float);
void tempCon(float);
void coinFlp(float);
float inP(int,float,float,float);
float outP(float,float);
int isPrime(unsigned int);
;void prob1();
void prob2();
void prob3();
void prob4();
void prob5();
void prob6();
void prob7();
void prob8();
void prob9();

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char choice;
    
    //Loop on the menu
    do{
    
        //Input values
        cout<<"Choose from the list"<<endl;
        cout<<"Type 1 for Problem 1"<<endl;
        cout<<"Type 2 for Problem 2"<<endl;
        cout<<"Type 3 for Problem 3"<<endl;
        cout<<"Type 4 for Problem 4"<<endl;
        cout<<"Type 5 for Problem 5"<<endl;
        cout<<"Type 6 for Problem 6"<<endl;
        cout<<"Type 7 for Problem 7"<<endl;
        cout<<"Type 8 for Problem 8"<<endl;
        cout<<"Type 9 for Problem 9"<<endl<<endl;
        cout<<"IF YOU WANT TO EXIT HIT 0"<<endl;
        cin>>choice;

        //Switch to determine the Problem
        switch(choice){
            case '1':{prob1();break;}
            case '2':{prob2();break;}
            case '3':{prob3();break;}
            case '4':{prob4();break;}
            case '5':{prob5();break;}
            case '6':{prob6();break;}
            case '7':{prob7();break;}
            case '8':{prob8();break;}
            case '9':{prob9();break;}
            default:
                cout<<"You are exiting the program"<<endl;
        }
    }while(choice>='1'&&choice<='9');
    
    //Exit stage right!
    return 0;
}
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem1 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 31, 2017, 9:07 PM
 * Purpose:  This Program asks for the wholesale price of an item and its markup
 *                  percentage and displays its retail price
 */
//******************************************************************************
void prob1(){
    cout<<"Inside Problem 1 function"<<endl;
 
    //Declare all Variables Here
    float whole;
    float markup;
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    calRetl (whole,markup);
    
    
}
void calRetl (float whole,float markup){
    float total=0.00f;
    cout<<"What is the cost of an item at whole sale price?"<<endl;
    cin>>whole;
    if(whole>0){
        cout<<"What is the markup percentage when it is sold at retail?"<<endl;
    cin>>markup;
    }
    else {
        cout<<"Can not accept negative numbers please enter a positive"
            "number for the wholesale price"<<endl;
        cin>>whole;
    }

    total=whole+(whole*(markup/100.00f));
    cout<<"If an items wholesale price is $"<<whole<<" and its markup percentage"
            " is "<<markup<<"%, then the items retail price is = "
            "$"<<total<<endl;
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem2 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017 12:21 PM
 * Purpose:  Finds the best sales division when the user enters
 *               their sales for the quarter
 */
//******************************************************************************
void prob2(){
    cout<<"Inside Problem 2 function"<<endl;
    
    //Declare all Variables Here
    float NE;//North East
    float SE;//South East
    float NW;//North West
    float SW;//South West
    
    //Process/Calculations Here
    cout<<"Input the North East sales for the last quarter in $"<<endl;
    cout<<getsale(NE)<<endl;
    cout<<"Input the South East sales for the last quarter in $"<<endl;
    cout<<getsale(SE)<<endl;
    cout<<"Input the North West sales for the last quarter in $"<<endl;
    cout<<getsale(NW)<<endl;
    cout<<"Input the South West sales for the last quarter in $"<<endl;
    cout<<getsale(SW)<<endl;
    cout<<endl<<endl;
            fndHigh (NE,SE,NW,SW);
        
}
float getsale(float & num){
    do {
    cin>>num;
    if(num<0){cout<<"sorry no negative numbers allowed"<<endl;}
    }while (num<0.00);
    cout<<"$";
    return num;
}
void  fndHigh(float NE,float SE,float NW,float SW){
    const char *who="The North East";
    float high=NE;
    if(SE>high){
        who="The South East";
        high==SE;
    }
    if(NW>high){
        who="The North West";
        high=NW;
    }
    if(SW>high){
        who="The South West";
        high=SW;
    }
    cout<<who<<" had the highest sales with $"<<high<<endl;
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem3 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017 1:21 PM
 * Purpose:  Finds the best area of the city to drive based on number of 
 *              reported accident in each area
 */
//******************************************************************************
void prob3(){
    cout<<"Inside Problem 3 function"<<endl;
    //Declare all Variables Here
    int NE;//North East
    int SE;//South East
    int NW;//North West
    int SW;//South West
    int CEN;//Central
    
    //Process/Calculations Here
    cout<<"Input the reported amount of crashes in the North East "<<endl;
    cout<<Acident(NE)<<endl;
    cout<<"Input the reported amount of crashes in the South East "<<endl;
    cout<<Acident(SE)<<endl;
    cout<<"Input the reported amount of crashes in the North West "<<endl;
    cout<<Acident(NW)<<endl;
    cout<<"Input the reported amount of crashes in the South West "<<endl;
    cout<<Acident(SW)<<endl;
    cout<<"Input the reported amount of crashes in the Center of town"<<endl;
    cout<<Acident(CEN)<<endl;
    cout<<endl<<endl;
            fndLow (NE,SE,NW,SW,CEN);
        
}
int Acident(int & num){
    do {
    cin>>num;
    if(num<0){cout<<"sorry no negative numbers allowed"<<endl;}
    }while (num<0.00);
    return num;
}
void  fndLow(int NE,int SE,int NW,int SW,int CEN){
    const char *who="The North East";
    float low=NE;
    if(SE<low){
        who="The South East";
        low==SE;
    }
    if(NW<low){
        who="The North West";
        low=NW;
    }
    if(SW<low){
        who="The South West";
        low=SW;
    }
    if(CEN<low){
        who="The Center";
        low=CEN;
    }
    cout<<who<<" had the lowest amount of crashes in the city with "<<low<<
            " crashes which means its safest to drive there"<<endl;
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem4 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017, 1:37 PM
 * Purpose:  This program will ask for the amount of time an object has fallen
             and it will tell you how far it actually fell in meters 
 *           after every second
 */
//******************************************************************************
void prob4(){
    cout<<"Inside Problem 4 function"<<endl;
    //Declare all Variables Here
    float distance;

    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"This program will ask for the amount of time an object has fallen"
            " and it will tell you how far it actually fell in meters"
            " after every second"<<endl;
    disFall(distance);
 
}
void disFall(float distance){
    float time;//How long it fell
    float d;//How far it fell;
    cout<<"How long did the object fall in seconds?"<<endl;
    cin>>time;
    for (int i=1;i<=time;i++){
        d=.5*g*(i*i);
        cout<<"At "<<i<<" second(s) the object fell "<<
                d<<" meters"<<endl;
    }
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem5 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017, 7:00 PM
 * Purpose:  This program will ask for the mass of an object in kg and 
                its velocity in meters per second and it will tell 
                you its kinetic energy
 */
//******************************************************************************
void prob5(){
    cout<<"Inside Problem 5 function"<<endl;
    //Declare all Variables Here
    float KinEngy;//Kinetic Energy

    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"This program will ask for the mass of an object in kg and "
            "its velocity in meters per second and it will tell "
            "you its kinetic energy"<<endl;
    kEnergy(KinEngy);
 
}
void kEnergy(float KinEngy){
    float mass;//Mass of object
    float vel;//Velocity of object
    float KE;//Kinetic Energy
    cout<<"What is the mass of the object in kg?"<<endl;
    cin>>mass;
    cout<<"What is the velocity of the object in m/s?"<<endl;
    cin>>vel;
    KE=.5*mass*(vel*vel);//Kinetic Energy calculations
    cout<<"The kinetic energy of the object is "<<KE<<endl;
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem6 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017, 8:30 PM
 * Purpose:  Enter any temperature in Celsius and this program will convert it
            and the next 20 degrees to Fahrenheit
 */
//******************************************************************************
void prob6(){
    cout<<"Inside Problem 6 function"<<endl;
    //Declare all Variables Here
    float CtoF;//Kinetic Energy
    
    //Output Located Here
    tempCon(CtoF);
 
}
void tempCon(float CtoF){
    float C,i,F;//Celsius and Fahrenheit 
    
    //Input values
    cout<<"Enter any temperature in Celsius and this program will convert it"
            "and the next 20 degrees to Fahrenheit"<<endl;
    cout<<"What temperature in Celsius would you like to start with"<<endl;
    cin>>C;
    i=C;//Used for loop
    cout<<"Temperature in:"<<endl;
    cout<<"C                    F"<<endl;
    cout<<"_______________________"<<endl;
    
    //Process by mapping inputs to outputs
    for (i;i<=C+20;i++){//Outputs initial conversion an next 20
        F=i*(1.8)+32;
        
        cout<<setw(2)<<i<<"               "<<setw(4)<<F<<endl;
    }
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem7 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017, 8:30 PM
 * Purpose:  This program will flip a coin as many times as the user wants
 *               and will output the results 
 */
//******************************************************************************
void prob7(){
    cout<<"Inside Problem 7 function"<<endl;
   //Declare all Variables Here
    unsigned int nThrows;
    
    //Input
    cout<<"This program will flip a coin as many times as you want and "
            "display the results"<<endl;
    cout<<"How many coin flips do you want"<<endl;
    cin>>nThrows;
    
    //Output Located Here

    coinFlp(nThrows);

    
}
void coinFlp(float nThrows){
    unsigned int  heads=1,tails=2,hcount=0,tcount=0;
     
    for (int i=1;i<=nThrows;i++){
    unsigned int flip=(rand()%2)+1;
    
    if (flip==heads){
        hcount++;
    }
    else if (flip==tails){
        tcount++;
    }
    }
    cout<<"Heads came up "<<hcount<<" times"<<endl;
    cout<<"Tails came up "<<tcount<<" times"<<endl;
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem8 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 2, 2017, 12:07 PM
 * Purpose:  Calculates the costs depending if the patient is an 
 *              in-patient or an out-patient.Questions are not the same for 
 *              both s costs could be quite different
 */
//******************************************************************************
void prob8(){
    cout<<"Inside Problem 8 function"<<endl;
    //Declare all Variables Here
    int inOrOut,nDays;//In-Patient or Out-Patient, number of days stayed
    float dayRate,medFees,serFees;//daily rate, medicine fees, service fees
    
    
    //Input or initialize values Here
    cout<<"This Program will ask if you are an in-Patient or an "
            "out-Patient"<<endl;
    cout<<"and then it will ask you questions depending on which you choose "
            "and then it will tell you how much you owe the hospital"<<endl;
    cout<<"Were you admitted as in-Patient or an out-Patient"<<endl;
    cout<<"Enter 0 if you are an in-Patient and 1 if you"
            " are an out-Patient"<<endl;
    cin>>inOrOut;
    while (inOrOut!=0&&inOrOut!=1){
        cout<<"Not a valid answer please enter 0 or 1"<<endl;
        cin>>inOrOut;
    }
    if (inOrOut==0){
        cout<<"How many days did you spend in the Hospital?"<<endl;
        cin>>nDays;
        cout<<"What was the daily rate in $'s of staying in th Hospital?"<<endl;
        cin>>dayRate;
        cout<<"What were the charges in $'s for the medication given?"<<endl;
        cin>>medFees;
        cout<<"What were the charges in $'s for the hospital services "
                "such as labs, tests, etc.?"<<endl;
        cin>>serFees;
        
        cout<<"The total in-Patient costs are = $"<<
                inP(nDays,dayRate,medFees,serFees)<<endl;
    }
    if (inOrOut==1){
        cout<<"What were the charges in $'s for the medication given?"<<endl;
        cin>>medFees;
        cout<<"What were the charges in $'s for the hospital services "
                "such as labs, tests, etc.?"<<endl;
        cin>>serFees;        
        
        cout<<"The total out-Patient costs are = $"<<
                outP(medFees,serFees)<<endl;
    }

}
float inP(int nDays,float dayRate,float medFees,float serFees){
    return (nDays*dayRate)+medFees+serFees;
}
float outP(float medFees,float serFees){
    return medFees+serFees;    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem9 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 2, 2017, 12:47 PM
 * Purpose:  Enter a number and the program will tell you if it is prime
 */
//******************************************************************************
void prob9(){
    cout<<"Inside Problem 9 function"<<endl;
    //Declare all Variables Here
    unsigned int num;
    
    //Input or initialize values Here
    cout<<"Enter any positive number greater than 0 and the program"
            " will tell you if it is prime"<<endl;
    cin>>num;
    while (num<1){
        cout<<"Can't accept that number please enter another"<<endl;
        cin>>num;
    }
    
    isPrime(num);
}
int isPrime(unsigned int num){
    int counter=0;
    int div;
    for (int i=2;i<num;i++){
        div=num%i;
        if (div==0){counter++;}
    }
    if (counter==0){
        cout<<num<<" is a prime number"<<endl;
    }
    if (counter>=1){
        cout<<num<<" is not a prime number"<<endl;
    }
}
