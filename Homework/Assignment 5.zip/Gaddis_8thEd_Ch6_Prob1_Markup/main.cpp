/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 31, 2017, 9:07 PM
 * Purpose:  This Program asks for the wholesale price of an item and its markup
 *                  percentage and displays its retail price
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
void calRetl (float,float);

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float whole;
    float markup;
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    calRetl (whole,markup);
    

    //Exit
    return 0;
}

void calRetl (float whole,float markup){
    float total=0.00f;
    cout<<"What is the cost of an item at whole sale price?"<<endl;
    cin>>whole;
    if(whole>0){
        cout<<"What is the markup percentage when it is sold at retail?"<<endl;
    cin>>markup;
    }
    else {
        cout<<"Can not accept negative numbers please enter a positive"
            "number for the wholesale price"<<endl;
        cin>>whole;
    }

    total=whole+(whole*(markup/100.00f));
    cout<<"If an items wholesale price is $"<<whole<<" and its markup percentage"
            " is "<<markup<<"%, then the items retail price is = "
            "$"<<total<<endl;
}

