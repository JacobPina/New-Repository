/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Feb 1, 2017 1:21 PM
 * Purpose:  Finds the best area of the city to drive based on number of 
 *              reported accident in each area
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here
int Acident(int&);
void  fndLow(int,int,int,int,int); 

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int NE;//North East
    int SE;//South East
    int NW;//North West
    int SW;//South West
    int CEN;//Central
    
    //Process/Calculations Here
    cout<<"Input the reported amount of crashes in the North East "<<endl;
    cout<<Acident(NE)<<endl;
    cout<<"Input the reported amount of crashes in the South East "<<endl;
    cout<<Acident(SE)<<endl;
    cout<<"Input the reported amount of crashes in the North West "<<endl;
    cout<<Acident(NW)<<endl;
    cout<<"Input the reported amount of crashes in the South West "<<endl;
    cout<<Acident(SW)<<endl;
    cout<<"Input the reported amount of crashes in the Center of town"<<endl;
    cout<<Acident(CEN)<<endl;
    cout<<endl<<endl;
            fndLow (NE,SE,NW,SW,CEN);
        
    //Exit
    return 0;
}

int Acident(int & num){
    do {
    cin>>num;
    if(num<0){cout<<"sorry no negative numbers allowed"<<endl;}
    }while (num<0.00);
    return num;
}
void  fndLow(int NE,int SE,int NW,int SW,int CEN){
    const char *who="The North East";
    float low=NE;
    if(SE<low){
        who="The South East";
        low==SE;
    }
    if(NW<low){
        who="The North West";
        low=NW;
    }
    if(SW<low){
        who="The South West";
        low=SW;
    }
    if(CEN<low){
        who="The Center";
        low=CEN;
    }
    cout<<who<<" had the lowest amount of crashes in the city with "<<low<<
            " crashes which means its safest to drive there"<<endl;
    
}

