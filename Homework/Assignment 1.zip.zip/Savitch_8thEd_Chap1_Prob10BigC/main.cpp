/* 
 * File:   main.cpp
 * Author: Jacob N.Piña
 * Created on Jan 5, 2017, 12:09 PM
 * Purpose:  
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char c;// Variable to build the letter c
    
    //Input or initialize values Here
    cout<<"This Program outputs a large C"<<endl;
    cout<<"With a letter the user chooses"<<endl;
    cout<<"What letter would you like?"<<endl;
    cin>>c;
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"  "<<c<<" "<<c<<" "<<c<<endl;
    cout<<""<<c<<"         "<<c<<endl;
    cout<<c<<endl;
    cout<<c<<endl;
    cout<<c<<endl;
    cout<<c<<endl;
    cout<<c<<endl;
    cout<<""<<c<<"         "<<c<<endl;
    cout<<"  "<<c<<" "<<c<<" "<<c<<endl;
    

    //Exit
    return 0;
}

