/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Hello World Template
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float meal,tax,tip,totBill;
    
    //Input or initialize values Here
    
     meal=88.67;//Cost of the meal in $
    tax=.0675;//Percent of tax put into a decimal (6.75%)
    tip=.20;// Percent of tip put into decimal ((20%)
    
    //Process/Calculations Here
    totBill=((meal+(meal*tax))+((meal+(meal*tax))*tip));
   
    //Output Located Here
    cout<<"If a meal cost is $"<<meal<<endl;
    cout<<"and if the tax on the meal is 6.75%"<<endl;
    cout<<"then if you add a tip of 20%"<<endl;
    cout<<"then your total paid will be = $"<<totBill<<endl;
    
    //Exit
    return 0;
}

