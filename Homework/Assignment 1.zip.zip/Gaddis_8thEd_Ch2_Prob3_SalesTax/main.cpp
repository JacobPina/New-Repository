/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 3, 2017, 12:15 PM
  Purpose:  Template to be used in all programming
            projects!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int sale; //amount in $ that a sale is
    float sTax, cTax;//State and County tax percentage
    float totSale; //Total sale after taxes
    //Input values
    sale=95;
    sTax=.04;
    cTax=.02;
    
    //Process by mapping inputs to outputs
    totSale=sale+(sale*sTax)+(sale*cTax);
    
    //Output values
    cout<<"The state sales tax is   4%"<<endl;
    cout<<"The county sales tax is  2%"<<endl;
    cout<<"So on a $"<<sale<<" purchase"<<endl;
    cout<<"The total amount after taxes would be = $"<<totSale<<endl;
    //Exit stage right!
    return 0;
}