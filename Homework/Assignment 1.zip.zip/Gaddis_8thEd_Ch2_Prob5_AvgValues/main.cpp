/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 9, 2017, 12:47 PM
 * Purpose:  Finding the average of 5 given numbers
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float v1,v2,v3,v4,v5,sum;
    float avg;
    
    //Input or initialize values Here
    v1=28,v2=32,v3=37,v4=24,v5=33;
   
    //Process/Calculations Here    
    sum=v1+v2+v3+v4+v5;
    avg=sum/5;
    //Output Located Here
    cout<<"If you are given 5 numbers:"<<endl;
    cout<<v1<<endl;
    cout<<v2<<endl;
    cout<<v3<<endl;
    cout<<v4<<endl;
    cout<<v5<<endl;
    cout<<"the sum of these 5 numbers is = "<<sum<<endl;
    cout<<"to find the average of these 5 numbers you must take the sum and divide by 5"<<endl;
    cout<<"this average is = "<<avg<<endl;
    
    //Exit
    return 0;
}

