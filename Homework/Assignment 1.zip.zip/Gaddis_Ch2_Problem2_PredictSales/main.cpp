/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 3, 2017, 12:15 PM
  Purpose:  Template to be used in all programming
            projects!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float prctSls;//Percentage of the sales from East Coast
    int totSls;//Total sales by the entire company
    int estSls;//Amount of sales in $ from East Coast
    
    //Input values
    prctSls=.58;
    totSls=8.6e6;
    
    //Process by mapping inputs to outputs
    estSls=prctSls*totSls;
    
    //Output values
    cout<<"If a company made a total of $"<<totSls<<endl;
    cout<<"And if 58 percent of the sales came from the East Coast"<<endl;
    cout<<"Then that means $"<<estSls<<" came from the East Coast"<<endl;
    //Exit stage right!
    return 0;
}