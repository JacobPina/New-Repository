/* 
 * File:   main.cpp
 * Author: Jacob N.Piña
 * Created on Jan 5, 2017, 12:09 PM
 * Purpose:  Calculate Pocket Change
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    const char quarter=25,//Number of cents in coinage           
               dime=10,
               penny=1,
               nickle=5;
    char nQtrs,nDimes,nNickls,nPenies;
    unsigned short total;//total pocketchange in cents
    
    //Input or initialize values Here
    cout<<"This calculates the amount of your pocket change"<<endl;
    cout<<"How many quarters, nickels, dimes, and pennies do you have"<<endl;
    cout<<"Type in all on the same line i.e. 3 4 5 6"<<endl;
    cout<<"Maximum of any value must be less than 10"<<endl;
    cin>>nQtrs>>nDimes>>nNickls>>nPenies;
    
    //Process/Calculations Here
     total=(nQtrs-48)*quarter+
            (nDimes-48)*dime+
            (nNickls-48)*nickle+
            (nPenies-48)*penny;
    //Output Located Here
     cout<<"The coins in your pocket="<<total<<"cents"<<endl;
     cout<<"The coind=s in your pocket=$."<<total<<endl;
        

    //Exit
    return 0;
}

