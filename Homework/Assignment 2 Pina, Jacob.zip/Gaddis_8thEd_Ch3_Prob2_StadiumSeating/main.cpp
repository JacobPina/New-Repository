/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 11, 2017, 1:30 PM
  Purpose:  This program finds the amount of $s generated from selling different 
 * tickets at different prices
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float tktACst,tktBCst,tktCCst;//Ticket class each is sold at different price
    float tktA,tktB,tktC;//Amount of each tick sold
    float totSls;//total sales in $s
    
    //Input values
    tktACst=15;
    tktBCst=12;
    tktCCst=9;
   
    cout<<"How many Class A tickets were sold?"<<endl;
    cin>>tktA;
    cout<<"How many Class B tickets were sold?"<<endl;
    cin>>tktB;
    cout<<"How many Class C tickets were sold?"<<endl;
    cin>>tktC;
    
    //Process by mapping inputs to outputs
    totSls=(tktACst*tktA)+(tktBCst*tktB)+(tktCCst*tktC);
    
    //Output values
    cout<<"Since the cost of a Class A ticket cost $"<<tktACst<<endl;
    cout<<"And the cost of a Class B ticket cost $"<<tktBCst<<endl;
    cout<<"And the cost of a Class C ticket cost $"<<tktCCst<<endl;
    cout<<"Then that means you made $"<<totSls<<" from selling tickets!"<<endl;
            
    //Exit stage right!
    return 0;
}