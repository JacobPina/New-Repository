/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 12, 2017, 1:00 PM
 * Purpose:  This Program takes a given recipe which gives a specific
 * amount of cookies and will convert the ingredients to the amount
 * the user wants to make
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float sugar,butter,flour;//Amount of ingredients the recipe calls for
    float cSug,cBut,cFlo;//Final converted amounts of sugar butter and flour
    float cookies;//Amount of cookies the user wants to make
    
    //Input or initialize values Here
    sugar=1.5;//Each in cups
    butter=1;
    flour=2.75;
        
    //Process/Calculations Here
    cout<<"A cookie recipe calls for the following ingredients:"<<endl;
    cout<<"- 1.5 cups of sugar"<<endl;
    cout<<"- 1 cup of butter"<<endl;
    cout<<"- 2.75 cups of flour"<<endl<<endl;
    cout<<"This recipe will make 48 cookies with this amount of ingredients"
            <<endl;
    cout<<"This program will change the quantity of each ingredient so it will"
            "make the amount of cookies you want"<<endl;
    cout<<"How many cookies do you want to make?"<<endl;
    cin>>cookies;
    
    cSug=(cookies*sugar)/48;
    cBut=(cookies*butter)/48;
    cFlo=(cookies*flour)/48;
    
    //Output Located Here
    cout<<"You will then need "<<setprecision(3)<<cSug<<" cups of sugar"<<endl;
    cout<<setprecision(3)<<cBut<<" cups of butter"<<endl;
    cout<<"and "<<setprecision(3)<<cFlo<<" cups of flour"<<endl;

    //Exit
    return 0;
}

