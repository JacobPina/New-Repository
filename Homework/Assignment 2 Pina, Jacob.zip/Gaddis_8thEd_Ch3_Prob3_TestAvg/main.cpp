/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 11, 2017, 1:45 PM
  Purpose:  This program will ask for 5 test scores and calculate your average.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int test1,test2,test3,test4,test5;//You will input all 5 test scores
    float testAvg;//Average of all 5 test scores
    
    //Input values
    cout<<"This program will ask you for 5 test scores and then it will "<<
            "display your average"<<endl;
    cout<<"Please enter test score 1"<<endl;
    cin>>test1;
    cout<<"Please enter test score 2"<<endl;
    cin>>test2;
    cout<<"Please enter test score 3"<<endl;
    cin>>test3;
    cout<<"Please enter test score 4"<<endl;
    cin>>test4;
    cout<<"Please enter test score 5"<<endl;
    cin>>test5;
            
            
    //Process by mapping inputs to outputs
    testAvg=(static_cast<float>(test1)+test2+test3+test4+test5)/5;//Calculated test average
    
    //Output values
    cout<<"Your average test score is "<<testAvg<<endl;
    //Exit stage right!
    return 0;
}