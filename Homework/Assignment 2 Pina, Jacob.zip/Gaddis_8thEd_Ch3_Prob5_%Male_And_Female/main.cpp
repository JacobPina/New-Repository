#include<iostream>
using namespace std;
 
int main(){
	float pcntM, pcntF;
	int nMale, nFemale, total;
 
	cout<<"Please enter the number of Male students in a class followed by"
                " a space and then the number of Female students in a class."<<
                endl;
	cin>>nMale>>nFemale;
 
	total = nMale + nFemale;
	pcntM = static_cast<float>(nMale)/total;
	pcntF = static_cast<float>(nFemale)/total;
 
	cout<<"Percentage of Male students is "<<pcntM*100<<"%."<<endl;
	cout<<"Percentage of Female students is "<<pcntF*100<<"%."<<endl;	
 
	return 0;
}