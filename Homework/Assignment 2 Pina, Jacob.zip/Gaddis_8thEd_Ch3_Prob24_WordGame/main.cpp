/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on July 19, 2016, 9:07 AM
 * Purpose: Word game
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char name,age,city,college,profesn,animal,petName;
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"We are going to play a word game!"<<endl;
    cout<<"But first I need some words from you."<<endl;
    cout<<"What is your name ?"<<endl;
    cin>>name;
    cout<<"What is your age ?"<<endl;
    cin>>age;
    cout<<"Name a city you want to visit"<<endl;
    cin>>city;
    cout<<"Name a college you want to go to"<<endl;
    cin>>college;
    cout<<"Name a profession you want to pursue"<<endl;
    cin>>profesn;
    cout<<"Name any kind of animal"<<endl;
    cin>>animal;
    cout<<"Give a pet name"<<endl;
    cin>>petName;
    cout<<"There once was a person named "<<name<<" who lived in "<<city<<endl;
    cout<<"At the age of "<<age<<", "<<name<<" went to college at "<<college<<endl;
    cout<<name<<" graduated and went to work as an "<<profesn<<"."<<endl;
    cout<<"Then, "<<name<<" adopted a(n) "<<animal<<" named "<<petName<<"."<<endl;
    cout<<"They both lived happily ever after!"<<endl;
    
    //Exit
    return 0;
}

