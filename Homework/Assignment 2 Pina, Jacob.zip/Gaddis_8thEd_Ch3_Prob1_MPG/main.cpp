/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 11, 2017, 1:15 PM
  Purpose:  This program calculates a car's gas mileage given the amount of gas
 * the car can hold and how far it can get on a full tank.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float GGCH;//The amount of Gallons of Gas the Car can Hold
    float MOFT;//The amount of Miles the car can get On a Full Tank
    float MPG; //The miles per gallon
    
    //Input values
    cout<<"How many gallons of gas can your car hold?"<<endl;
    cin>>GGCH;
    cout<<"How many miles can you get on a full tank of gas?"<<endl;
    cin>>MOFT;
    
    //Process by mapping inputs to outputs
    MPG=MOFT/GGCH;//Calculates the MPG 
    
    //Output values
    cout<<"Your car gets "<<MPG<<" miles per gallon"<<endl;
    
    //Exit stage right!
    return 0;
}