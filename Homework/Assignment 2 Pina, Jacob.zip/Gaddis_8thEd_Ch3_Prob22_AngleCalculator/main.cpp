/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on July 19, 2016, 9:07 AM
 * Purpose:  Finding the sin, cos, and tan of an angle given by the user
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions
float PI=3.14159;
//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float anglex,sinx,cosx,tanx;//Angle input, sin,cos, and tangent of angle input
    
    //Input or initialize values Here
    
    //Process/Calculations Here
    
    //Output Located Here
    cout<<"Enter angle theta"<<endl;  
    cin>>anglex;
    sinx=sin(anglex*PI/180);
    cosx=cos(anglex*PI/180);
    tanx=tan(anglex*PI/180);
    
    cout<<"sin of angle theta is = "<<setprecision(4)<<sinx<<endl;
    cout<<"cos of angle theta is = "<<setprecision(4)<<cosx<<endl;
    cout<<"tan of angle theta is = "<<setprecision(4)<<tanx<<endl;
    //Exit
    return 0;
}

