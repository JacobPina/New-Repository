/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 12, 2017, 1:29 PM
 * Purpose:  Box Office
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int aTkts,cTkts;//Amount of adult and children tickets sold
    float prceA,prceC;//Price for an adult and child ticket
    float totSls;//Total sales from the movie
    float net,distrib; /*net income for theater and amount 
                            that goes to the distributer
                             */
    
    //Input or initialize values Here
    prceA=10.00;//Price in dollars
    prceC=6.00;
       
    //Process/Calculations Here
    cout<<"How many adult movie tickets were sold?"<<endl;
    cin>>aTkts;
    cout<<"How many childrens tickets were sold?"<<endl;
    cin>>cTkts;
    totSls=(aTkts*prceA)+(cTkts*prceC);
    net=totSls/5;
    distrib=totSls-net;
    
    
    //Output Located Here
    cout<<"Adult Tickets Sold:        "<<aTkts<<endl;
    cout<<"Child Tickets Sold:        "<<cTkts<<endl;
    cout<<"Total Sales Box Office    $"<<totSls<<endl;
    cout<<"Amount Theater Keeps      $"<<net<<endl;
    cout<<"Amount to Distributor     $"<<distrib<<endl;
    //Exit
    return 0;
}

