/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 12, 2017, 12:55 PM
 * Purpose:  This program calculates the average rainfall for the months of 
 * June July and August
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float juneR,julyR,augR; //Amount of rainfall in inches in each month
    float avgR; //Average rainfall of the given months
    
    //Input or initialize values Here
    
            
    //Process/Calculations Here
    cout<<"This program calculates the average rainfall for the months of "
            "June July and August"<<endl;
    cout<<"Please enter the amount of rain in inches that came in June"<<
            endl;
    cin>>juneR;
    cout<<"Please enter the amount of rain in inches that came in July"<<
            endl;
    cin>>julyR;
    cout<<"Please enter the amount of rain in inches that came in August"<<
            endl;
    cin>>augR;
    
    avgR=(juneR+julyR+augR)/3;
    
    //Output Located Here
    cout<<"The average rainfall for June, July and August is "<<
           setprecision(4)<<avgR<<" inches"<<endl;
 

    //Exit
    return 0;
}

