/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on Jan 12, 2017, 9:15 PM
  Purpose:  This Program Converts Celsius to Fahrenheit
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float C,F; //Temperature in Celsius and Fahrenheit 
    
    //Input values
    cout<<"This program will convert the temperature from Celsius to "
            "Fahrenheit"<<endl;
    cout<<"Please enter the temperature in Celsius"<<endl;
    cin>>C;
    F=(1.8*C)+32;
    cout<<"This temperature is equal to "<<setprecision(3)<<F<<
            " degrees Fahrenheit"<<endl;
    //Process by mapping inputs to outputs
    
    //Output values
    
    //Exit stage right!
    return 0;
}