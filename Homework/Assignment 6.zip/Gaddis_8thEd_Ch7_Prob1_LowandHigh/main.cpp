/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 3, 2017, 12:15 PM
  Purpose:  To ask the user for an array of numbers and then display the
 *           lowest and highest
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int min,max;
    const int arayNum=10;//Number that goes into array
    int a[arayNum];//10 elements
    
    //Input values and process them
    cout<<"Enter 10 numbers and the program will display the lowest"
            " and highest"<<endl;
    for(int i=0;i<arayNum;i++){
        cout<<"Enter a number"<<endl;
        cin>>a[i];
    }
    min=a[0];
    max=a[0];
for (int i=0;i<arayNum;i++){
    if (min>a[i]){
        min=a[i];
    }
    else if (max<a[i]){
        max=a[i];
    }
}    

//Output Values Here
    cout<<"The smallest number is "<<min<<endl;
    cout<<"The biggest number is  "<<max<<endl;
    //Exit stage right!
    return 0;
}