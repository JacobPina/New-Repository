/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 3, 2017, 12:15 PM
  Purpose:  Template to be used in all programming
            projects!
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    const int MONTHS = 12;
    int count = 0;
    string name[MONTHS] = {"January","February","March","April","May","June",
            "July","August","September","October","November","December"};
    double rain[MONTHS],avg,year=0,highest,lowest;
    string highM, lowM;
    
    //Input values
    for (count=0;count<MONTHS;count++){ 
            // ask user to enter amount of rainfall for each month
	
            cout <<"How many inches of rain does "<<name[count]<<" have?"<<endl;
	    cin >> rain[count];
	    while (rain[count]<0)
		{
		cout << "Please enter a number greater than 0." << endl;
		cin >> rain[count];
		}
	}

    
    //Process by mapping inputs to outputs
	highest=rain[0]; // finds month with the highest amount of rain
	lowest=rain[0]; // finds month with the least amount of rain
        
	for(count=1;count<MONTHS;count++)
	{
		if (rain[count]>highest)
		{
			highM=name[count];
			highest=rain[count];
		}
		else if (rain[count]<lowest)
		{
			lowM=name[count];
			lowest=rain[count];
		}
	}    
    //Output values
        for(count=0;count<MONTHS;count++)
	{
		year+=rain[count];
		cout<<name[count]<<" has "<<rain[count]<<
                        " inches of rainfall"<<endl;
	}
        	avg=year/MONTHS;

	cout<<endl<<setprecision(2)<<fixed;
	cout<<"Total Rainfall throughout the year is "<<year<<" inches"<<endl;
	cout<<"The average monthly rainfall is "<<avg<<" inches"<<endl;
	cout<<"The month with the highest amount of rainfall is "<<highM<<
                " with "<< highest<<" inches."<<endl;
	cout<<"The month with the lowest amount of rainfall is "<<lowM<<
                " with "<<lowest<<" inches."<<endl;

    //Exit stage right!
    return 0;
}