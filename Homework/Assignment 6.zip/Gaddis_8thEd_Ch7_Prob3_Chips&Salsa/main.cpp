/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 3, 2017, 12:15 PM
  Purpose:  
 Write a program that lets a maker of chips and salsa keep track of sales for
 *  five different types of salsa: mild, medium, sweet, hot, and zesty. The
 *  program should use two parallel 5-element arrays: an array of strings that
 *  holds the five salsa names and an array of integers that holds the number
 *  of jars sold during the past month for each salsa type. The salsa names
 *  should be stored using an initialization list at the time the name array
 *  is created. The program should prompt the user to enter the number of jars
 *  sold for each type. Once this sales data has been entered, the program
 *  should produce a report that displays sales for each salsa type, total
 *  sales, and the names of the highest selling and lowest selling products. 
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes
int getTotl(int [], int);
int posSmal(int [], int);
int posLarg(int [], int);

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
   const int NUMTYPE=5;   
   int sales[NUMTYPE];
   string name[NUMTYPE]={"Mild","Medium","Sweet","Hot","Zesty"};
   
   // Create the arrays for the names and sales amounts
    int totJars,hiSales,loSales;
    
    //Input values
    for (int type=0;type<NUMTYPE;type++)
	{
	cout<<"Jars sold last month of "<<name[type]<<":";
      	cin>>sales[type];
            while (sales[type] < 0)
		{cout<<"Jars sold must be 0 or more. Please re-enter:";
                 cin>>sales[type];
		}
	}
   
   // Call functions to get total sales and high and low selling products
   totJars=getTotl(sales, 5);
   loSales=posSmal(sales, 5);
   hiSales=posLarg(sales, 5);
   
   // Produce the sales report
   cout<<endl<<endl;
   cout<<"     Salsa Sales Report"<<endl<<endl;
   cout<<"Name              Jars Sold"<<endl;
   cout<<"____________________________"<<endl;
   
    cout<<name[0]<<"                    "<<sales[0]<<endl;
    cout<<name[1]<<"                  "<<sales[1]<<endl;
    cout<<name[2]<<"                   "<<sales[2]<<endl;
    cout<<name[3]<<"                     "<<sales[3]<<endl;
    cout<<name[4]<<"                   "<<sales[4]<<endl;  

    // insert the code that prints the salsa names and number jars sold
   
   cout<<"Total Sales:"<<setw(15)<<totJars<<endl;
   cout<<"High Seller:"<<name[hiSales]<<endl;
   cout<<"Low Seller :"<<name[loSales]<<endl;    
   
    //Exit stage right!
    return 0;
}

int getTotl (int array[], int numElts)
{
	int total=0;
	for (int type=0;type<numElts;type++)
		total+=array[type];
	return total;
}

int posLarg(int array[], int numElts)
{
	int Largest = 0;
	for (int pos=1;pos<numElts; pos++)
	{
            if (array[pos]>array[Largest])
		Largest=pos;
	}
	return Largest;
}

int posSmal(int array[], int numElts)
{
	int Smalest=0;
	for (int pos=1;pos<numElts;pos++)
	{
            if (array[pos]<array[Smalest])
		Smalest=pos;
	}		
	return Smalest;
}
