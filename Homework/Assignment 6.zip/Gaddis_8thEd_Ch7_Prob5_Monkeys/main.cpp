/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on Feb 6, 2017, 12:15 PM
  Purpose:  
 A local zoo wants to keep track of how many pounds of food each of its three
 *  monkeys eats each day during a typical week. Write a program that stores
 *  this information in a two-dimensional 3 × 5 array, where each row represents
 *  a different monkey and each column represents a different day of the week.
 *  The program should first have the user input the data for each monkey.
 */

#include<iostream>
using namespace std;

int main()
{
	const int MONKEYS= 3;
	const int DAYS= 7;
	int food[MONKEYS][DAYS];
	int max= food[0][0];
	int min= food[0][0];
	float total= 0.0f;
	float avg= 0.0f;


	cout<<"Enter the amount of food consumed for each monkey on each day:"
                <<endl;

	//get data from user and sum it
	for (int monk=0;monk<MONKEYS;monk++)
	{
		for (int day=0;day<DAYS;day++)
		{
			cout<<"Monkey "<<(monk + 1)<<", day "<<(day + 1)<<": ";
			cin>>food[monk][day];

			total+=food[monk][day];
		}
		cout<<endl;
	}
	//calculate average
	avg=total/(MONKEYS*DAYS);

	//get most eaten
	for (int monk=0;monk<MONKEYS;monk++)
	{
		for (int day=0;day<DAYS;day++)
		{
		if (food[monk][day]>max)
			max=food[monk][day];
		}
	}

	//get least eaten
	for (int monk=0;monk<MONKEYS;monk++)
	{
		for (int day=0;day<DAYS;day++)
		{
		if (food[monk][day]<min)
			min=food[monk][day];
		}
	}

	cout<<"            Report"<<endl;
	cout<<"-----------------------------"<<endl;
	cout<<endl;
	cout<<"The total amount of food consumed is "<<total<<endl;
	cout<<"The average amount of food consumed by the monkeys each "
                "day is "<<avg<<endl;
	cout<<"The most eaten by a monkey is "<<max<<endl;
	cout<<"The least eaten by a monkey is "<<min<<endl;
        
	return 0;
}

