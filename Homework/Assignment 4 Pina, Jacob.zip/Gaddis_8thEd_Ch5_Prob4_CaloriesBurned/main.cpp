/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 19, 2016, 9:07 AM
 * Purpose:  This Program shows the user how many calories would be burned 
 * after using the treadmill for X amount of hours
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float calBrnd=0.0;//How many calories you burned at beginning
    
    
    //Input or initialize values Here
    cout<<"You burn about 3.6 calories every minute running "
            "on the treadmill"<<endl; 
    cout<<"This program will tell you how many calories you burned after"
            " running on the treadmill every 5 minutes"<<endl<<endl;
       
    for(int min=1;min<=30;min++){
        calBrnd+=3.6f;
        if(min%5==0)
    cout<<"You will burn "<<setw(3)<<calBrnd<<
            " calories after "<<setw(3)<<min<<" minutes"<<endl;
            
    }
    
    //Process/Calculations Here
    
    //Output Located Here


    //Exit
    return 0;
}

