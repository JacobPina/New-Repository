/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 19, 2017, 5:15 PM
  Purpose:  Write a program that will predict the size of a population of 
 *     organisms. The program should ask the user for the starting number of 
 *     organisms, their average daily population increase (as a percentage), and 
 *     the number of days they will multiply. A loop should display the size of 
 *     the population for each day.   Input Validation: Do not accept a number 
 *     less than 2 for the starting size of the population. Do not accept a  
 *     negative number for average daily population increase. Do not accept a 
 *     number less than 1 for the number of days they will multiply
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
float PERCENT=100; //Used for percentage conversions
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int orgnsms,maxDays;//Number of organisms to start with and days examined
    float popIncs;// population increase daily as a percentage(%)
    
    //Input values
    cout<<"How many organisms are there to begin with?"<<endl;
    cin>>orgnsms;
    
    
    //Process by mapping inputs to outputs
    if (orgnsms>=2){
    cout<<"How What is their average daily population increase as "
            "a percentage?"<<endl;
    cin>>popIncs;
    cout<<"How many days are we going to observe the organisms?"<<endl;
    cin>>maxDays;  
        
    for(int day=1;day<=maxDays;day++){
        orgnsms=(orgnsms*popIncs/PERCENT)+orgnsms;
        cout<<"After "<<setw(3)<<day<<" days there will be "<<setw(6)<<orgnsms<<
                " organisms"<<endl;
    }
    }
    else if (orgnsms<2){
        cout<<"There can't be less than 2 organisms to start with"<<endl;
        cout<<"Restart the program and enter a number greater than "
                "or equal to 2"<<endl;
    }
    //Output values
    
    //Exit stage right!
    return 0;
}