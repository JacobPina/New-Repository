/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 19, 2017, 1:27 PM
 * Purpose:  Assuming the ocean lever is rising at about 1.5 millimeters per 
 *  year display a table showing how much the ocean will rise over the next 25
 *  years
 */

//System Libraries Here
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float ocnLevl=0.0;
    
    
    //Input or initialize values Here
    cout<<"The ocean level is rising at about 1.5mm every year, This program "
            "will estimate how much the ocean level will rise for the next"
            "25 years."<<endl<<endl;;
    for(int year=1;year<=25;year++){\
        ocnLevl+=1.5f;
    cout<<"The ocean level will rise about "<<setw(4)<<ocnLevl<<
            " millimeters in "<<setw(3)<<year<<" years"<<endl;
            
    }
        
    
    //Process/Calculations Here
    
    //Output Located Here
    

    //Exit
    return 0;
}

