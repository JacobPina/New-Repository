/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 19, 2017, 10:07 AM
 * Purpose:  
 A country club, which currently charges $2,500 per year for membership, 
 *  has announced it will increase its membership fee by 4% each year for the
 *  next six years. Write a program that uses a loop to display the projected
 *  rates for the next six years. 
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    float fee=2500;//Membership fee
    float addFee=.04;//Percentage added to next years fee
    float totMem;//Total Cost for Membership
    
    //Input or initialize values Here
    cout<<"The starting membership Fee is $"<<fee<<" per year"<<endl;
    
    //Process/Calculations Here
    for(int years=1;years<=6;years++){
        fee+=(fee*addFee);
        cout<<"The membership fee in "<<years<<" years is $"<<fee<<endl;
        
    }
    
    //Output Located Here
    

    //Exit
    return 0;
}

