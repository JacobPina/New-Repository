/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 19, 2017, 12:15 PM
  Purpose: This Program asks the user for the speed of a vehicle in mph 
 *  and how long the vehicle traveled for and displays how far
    each hour the vehicle has gone
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float distance,rate,time;//Distance in miles, rate in mph,time in hours
    
    
    //Input values
    cout<<"This Program asks the user for the speed of a vehicle in mph "<<endl
            <<"and how long the vehicle traveled for and displays how far"<<endl
            <<"each hour the vehicle has gone"<<endl<<endl;
    cout<<"What is the speed of your vehicle in mph?"<<endl;
    cin>>rate;
    if(rate>=1){
    cout<<"How many hours did you drive?"<<endl;
    cin>>time;
    cout<<"HOUR       DISTANCE TRAVELED"<<endl;
    cout<<"____________________________"<<endl;
    
    //Process by mapping inputs to outputs
    for(int everyhr=1;everyhr<=time;everyhr++){
        distance=rate*everyhr;
        cout<<everyhr<<"               "<<distance<<" miles"<<endl;
    }
    }
    //Output values
    else if(rate<1){
        cout<<"Sorry this program does not allow numbers below 1 mph"<<endl;
    }
    //Exit stage right!
    return 0;
}