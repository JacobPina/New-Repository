/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 18, 2017, 1:07 PM
 * Purpose:  This Program will ask for a number (N) and it will add up every
 * number before it until it gets to N.
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    int num;            //Starting Number n
    float sum=0.0;    //Total added 1+2+3+4+5...+n
    
    //Input or initialize values Here
    cout<<"Enter what number you would like to add up to"<<endl;
    cin>>num;
    
    //Process/Calculations Here
    if(num>0){
    for(int i=0;i<=num;i++){
        sum+=i;//Adds the sum of the numbers until you get to n
       
    }
    
    cout<<sum<<endl;
    }
    else if (num<=0)
        cout<<"Sorry can't use this number"<<endl;
   
    //Output Located Here
    

    //Exit
    return 0;
}

