/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 19, 2017, 6:10 PM
  Purpose:  Menu to be used in Homework ASSIGNMENT 4
 */

//System Libraries
#include <iostream>//Input Output Library
#include <cstdlib> //Random number generator seed
#include <ctime>   //Time Library
#include <iomanip> //Format Library
#include <cmath>
using namespace std;

//User Libraries

//Global Constants
int PERCENT=100;//Used for percentage conversions
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to another

//Function Prototypes
;void prob1();
void prob2();
void prob3();
void prob4();
void prob5();
void prob6();
void prob7();
void prob8();
void prob9();

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char choice;
    
    //Loop on the menu
    do{
    
        //Input values
        cout<<"Choose from the list"<<endl;
        cout<<"Type 1 for Problem 1"<<endl;
        cout<<"Type 2 for Problem 2"<<endl;
        cout<<"Type 3 for Problem 3"<<endl;
        cout<<"Type 4 for Problem 4"<<endl;
        cout<<"Type 5 for Problem 5"<<endl;
        cout<<"Type 6 for Problem 6"<<endl;
        cout<<"Type 7 for Problem 7"<<endl;
        cout<<"Type 8 for Problem 8"<<endl;
        cout<<"Type 9 for Problem 9"<<endl<<endl;
        cout<<"IF YOU WANT TO EXIT HIT 0"<<endl;
        cin>>choice;

        //Switch to determine the Problem
        switch(choice){
            case '1':{prob1();break;}
            case '2':{prob2();break;}
            case '3':{prob3();break;}
            case '4':{prob4();break;}
            case '5':{prob5();break;}
            case '6':{prob6();break;}
            case '7':{prob7();break;}
            case '8':{prob8();break;}
            case '9':{prob9();break;}
            default:
                cout<<"You are exiting the program"<<endl;
        }
    }while(choice>='1'&&choice<='9');
    
    //Exit stage right!
    return 0;
}
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem1 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 18, 2017, 1:07 PM
 * Purpose:  This Program will ask for a number (N) and it will add up every
 * number before it until it gets to N.
 */
//******************************************************************************
void prob1(){
    cout<<"Inside Problem 1 function"<<endl;
 //Declare all Variables Here
    int num;            //Starting Number n
    float sum=0.0;    //Total added 1+2+3+4+5...+n
    
    //Input or initialize values Here
    cout<<"Enter what number you would like to add up to i.e. (if you pick 8"
            " you get 1+2+3+4+5+6+7+8)"<<endl;
    cin>>num;
    
    //Process/Calculations Here
    if(num>0){
    for(int i=0;i<=num;i++){
        sum+=i;//Adds the sum of the numbers until you get to n
       
    }
    
    cout<<sum<<endl;
    }
    else if (num<=0)
        cout<<"Sorry can't use this number"<<endl;
   
    //Output Located Here
    

    //Exit
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem2 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 18, 2017, 1:15 PM
 * Purpose:  This Program displays the first 127 characters in the ASCII code
 * 
 *            Note:The first 32 are commands or functions so they are either 
 *                  blank or small squares.
 */
//******************************************************************************
void prob2(){
    cout<<"Inside Problem 2 function"<<endl;
    //Declare all Variables Here
    char ascii;
    
    cout<<"This Program will display the first 127 characters in "
            "ASCII code with 16 characters in each row"<<endl;
    ascii=0;
    
    //Input or initialize values Here
    for (int i=0;i<=127;i++)
    {
        if (i%16==0)
            cout<<endl;
        
        cout<<ascii<<"  ";
        ascii++;
    }
    
    //Process/Calculations Here
    
    //Output Located Here
  

    //Exit
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem3 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 19, 2017, 1:27 PM
 * Purpose:  Assuming the ocean lever is rising at about 1.5 millimeters per 
 *  year display a table showing how much the ocean will rise over the next 25
 *  years
 */
//******************************************************************************
void prob3(){
    cout<<"Inside Problem 3 function"<<endl;
     //Declare all Variables Here
    float ocnLevl=0.0;
    
    
    //Input or initialize values Here
    cout<<"The ocean level is rising at about 1.5mm every year, This program "
            "will estimate how much the ocean level will rise for the next"
            "25 years."<<endl<<endl;;
    for(int year=1;year<=25;year++){\
        ocnLevl+=1.5f;
    cout<<"The ocean level will rise about "<<setw(4)<<ocnLevl<<
            " millimeters in "<<setw(3)<<year<<" years"<<endl;
            
    }
        
    
    //Process/Calculations Here
    
    //Output Located Here
    

    //Exit
   
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem4 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 19, 2016, 9:07 AM
 * Purpose:  This Program shows the user how many calories would be burned 
 * after using the treadmill for X amount of hours
 */
//******************************************************************************
void prob4(){
    cout<<"Inside Problem 4 function"<<endl;
    //Declare all Variables Here
    float calBrnd=0.0;//How many calories you burned at beginning
    
    
    //Input or initialize values Here
    cout<<"You burn about 3.6 calories every minute running "
            "on the treadmill"<<endl; 
    cout<<"This program will tell you how many calories you burned after"
            " running on the treadmill every 5 minutes"<<endl<<endl;
       
    for(int min=1;min<=30;min++){
        calBrnd+=3.6f;
        if(min%5==0)
    cout<<"You will burn "<<setw(3)<<calBrnd<<
            " calories after "<<setw(3)<<min<<" minutes"<<endl;
            
    }
    
    //Process/Calculations Here
    
    //Output Located Here


    //Exit
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem5 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 19, 2017, 10:07 AM
 * Purpose:  
 A country club, which currently charges $2,500 per year for membership, 
 *  has announced it will increase its membership fee by 4% each year for the
 *  next six years. Write a program that uses a loop to display the projected
 *  rates for the next six years. 
 */
//******************************************************************************
void prob5(){
    cout<<"Inside Problem 5 function"<<endl;
    //Declare all Variables Here
    float fee=2500;//Membership fee
    float addFee=.04;//Percentage added to next years fee
    float totMem;//Total Cost for Membership
    
    //Input or initialize values Here
    cout<<"The starting membership Fee is $"<<fee<<" per year"<<endl;
    
    //Process/Calculations Here
    for(int years=1;years<=6;years++){
        fee+=(fee*addFee);
        cout<<"The membership fee in "<<years<<" years is $"<<fee<<endl;
        
    }
    
    //Output Located Here
    

    //Exit
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem6 ***************************************
/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 19, 2017, 12:15 PM
  Purpose: This Program asks the user for the speed of a vehicle in mph 
 *  and how long the vehicle traveled for and displays how far
    each hour the vehicle has gone
 */
//******************************************************************************
void prob6(){
    cout<<"Inside Problem 6 function"<<endl;
    //Declare Variables
    float distance,rate,time;//Distance in miles, rate in mph,time in hours
    
    
    //Input values
    cout<<"This Program asks the user for the speed of a vehicle in mph "<<endl
            <<"and how long the vehicle traveled for and displays how far"<<endl
            <<"each hour the vehicle has gone"<<endl<<endl;
    cout<<"What is the speed of your vehicle in mph?"<<endl;
    cin>>rate;
    if(rate>=1){
    cout<<"How many hours did you drive?"<<endl;
    cin>>time;
    cout<<"HOUR       DISTANCE TRAVELED"<<endl;
    cout<<"____________________________"<<endl;
    
    //Process by mapping inputs to outputs
    for(int everyhr=1;everyhr<=time;everyhr++){
        distance=rate*everyhr;
        cout<<everyhr<<"               "<<distance<<" miles"<<endl;
    }
    }
    //Output values
    else if(rate<1){
        cout<<"Sorry this program does not allow numbers below 1 mph"<<endl;
    }
    //Exit stage right!
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem7 ***************************************
/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 19, 2017, 9:07 PM
 * Purpose:  
 Write a program that calculates how much a person would earn over a period
 *  of time if his or her salary is one penny the first day and two pennies
 *  the second day, and continues to double each day. The program should ask
 *  the user for the number of days. Display a table showing how much the
 *  salary was for each day, and then show the total pay at the end of the
 *  period. The output should be displayed in a dollar amount, not the
 *  number of pennies.   
 */
//******************************************************************************
void prob7(){
    cout<<"Inside Problem 7 function"<<endl;
    //Declare all Variables Here
    int salary=1,totPay=0,maxDays=30;//Salary in pay in pennies
    
    //Input or initialize values Here
    cout<<"This program will show the salary of someone that gets paid 1 penny"
            " on day one, 2 pennies on day two and it doubles every day for"
            " as many days as you want it to go."<<endl;
    
    //Process/Calculations Here
    for(int day=1;day<=maxDays;day++,salary*=2){
        int dollars;
        int cents;
        cents=salary%100;
        dollars=(salary-cents)/100;
        totPay+=salary;
        cout<<"Salary for day "<<day<<" = $"<<dollars<<"."
                <<(cents<10?'0':'\0')<<cents<<endl;
        cents=totPay%100;
        dollars=(totPay-cents)/100;
        cout<<"Total pay for day "<<day<<" = $"<<dollars<<"."
                <<(cents<10?'0':'\0')<<cents<<endl<<endl;
    }
    
    //Predicting results
    double salLDay=(pow(2,maxDays-1))/100;
    double totLDay=(pow(2,maxDays)-1)/100;
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Final Salary predicted = $"<<salLDay<<endl;
    cout<<"Final Total Pay predicted = $"<<totLDay<<endl;
    //Exit
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem8 ***************************************
/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 19, 2017, 5:15 PM
  Purpose:  Write a program that will predict the size of a population of 
 *     organisms. The program should ask the user for the starting number of 
 *     organisms, their average daily population increase (as a percentage), and 
 *     the number of days they will multiply. A loop should display the size of 
 *     the population for each day.   Input Validation: Do not accept a number 
 *     less than 2 for the starting size of the population. Do not accept a  
 *     negative number for average daily population increase. Do not accept a 
 *     number less than 1 for the number of days they will multiply
 */
//******************************************************************************
void prob8(){
    cout<<"Inside Problem 8 function"<<endl;
     //Declare Variables
    int orgnsms,maxDays;//Number of organisms to start with and days examined
    float popIncs;// population increase daily as a percentage(%)
    
    //Input values
    cout<<"This Program will display how many organisms there are after the"
            " user inputs the amount of organisms and how fast"
            " they multiply"<<endl;
    cout<<"How many organisms are there to begin with?"<<endl;
    cin>>orgnsms;
    
    
    //Process by mapping inputs to outputs
    if (orgnsms>=2){
    cout<<"How What is their average daily population increase as "
            "a percentage?"<<endl;
    cin>>popIncs;
    cout<<"How many days are we going to observe the organisms?"<<endl;
    cin>>maxDays;  
        
    for(int day=1;day<=maxDays;day++){
        orgnsms=(orgnsms*popIncs/PERCENT)+orgnsms;
        cout<<"After "<<setw(3)<<day<<" days there will be "<<setw(6)<<orgnsms<<
                " organisms"<<endl;
    }
    }
    else if (orgnsms<2){
        cout<<"There can't be less than 2 organisms to start with"<<endl;
        cout<<"Restart the program and enter a number greater than "
                "or equal to 2"<<endl;
    }
    //Output values
    
    //Exit stage right!
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem9 ***************************************
/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 19, 2017, 5:52 PM
  Purpose: In Programming Challenge 10 of  Chapter 3 you were asked to
 *      write a program that converts a Celsius temperature to Fahrenheit.
 *      Modify that program so it uses a loop to display a table of the 
 *      Celsius temperatures 0–20, and their Fahrenheit equivalents. 
*/
//******************************************************************************
void prob9(){
    cout<<"Inside Problem 9 function"<<endl;
     //Declare Variables
    float C=1,F;//Celsius and Fahrenheit 
    
    //Input values
    cout<<"This program shows the conversions from 0-20"
            " from Celsius to Fahrenheit"<<endl;
    cout<<"Temperature in:"<<endl;
    cout<<"C                    F"<<endl;
    cout<<"_______________________"<<endl;
    
    //Process by mapping inputs to outputs
    for (int temp=1;temp<=20;temp++){
        F=C*(1.8)+32;
        
        cout<<setw(2)<<C<<"               "<<setw(4)<<F<<endl;
        C++;  
    }
    //Output values
    
    //Exit stage right!
    
}
