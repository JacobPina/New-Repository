/* 
 * File:   main.cpp
 * Author: Jacob N. Piña
 * Created on Jan 18, 2017, 1:15 PM
 * Purpose:  This Program displays the first 127 characters in the ASCII code
 * 
 *            Note:The first 32 are commands or functions so they are either 
 *                  blank or small squares.
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    char ascii;
    
    cout<<"This Program will display the first 127 characters in "
            "ASCII code with 16 characters in each row"<<endl;
    ascii=0;
    
    //Input or initialize values Here
    for (int i=0;i<=127;i++)
    {
        if (i%16==0)
            cout<<endl;
        
        cout<<ascii<<"  ";
        ascii++;
    }
    
    //Process/Calculations Here
    
    //Output Located Here
  

    //Exit
    return 0;
}

