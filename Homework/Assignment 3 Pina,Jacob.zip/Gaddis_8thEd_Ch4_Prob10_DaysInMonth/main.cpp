/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 16, 2017, 6:01 PM
  Purpose:  Finds the amount of days in a month in any year
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int month,year;
    
    //Input values
    cout<<"This Program will tell you how many days are in any month in any "
            "given year, you just have to enter what month and year you want"
            <<endl;
    cout<<"Please enter a month as a number i.e. December = 12"<<endl<<endl;
    cin>>month;
    cout<<"Now enter any year i.e. 2017 = 2017"<<endl;
    cin>>year;
    
    //Process by mapping inputs to outputs
    
    //Output values
    if (month==1)
        cout<<"This month will have 31 days"<<endl;
    else if (month==3)
        cout<<"This month will have 31 days"<<endl;
    else if (month==5)
        cout<<"This month will have 31 days"<<endl;
    else if (month==7)
        cout<<"This month will have 31 days"<<endl;
    else if (month==8)
        cout<<"This month will have 31 days"<<endl;
    else if (month==10)
        cout<<"This month will have 31 days"<<endl;
    else if (month==12)
        cout<<"This month will have 31 days"<<endl;
    else if (month==4)
        cout<<"This month will have 30 days"<<endl;
    else if (month==6)
        cout<<"This month will have 30 days"<<endl;
    else if (month==9)
        cout<<"This month will have 30 days"<<endl;
    else if (month==11)
        cout<<"This month will have 30 days"<<endl;
    else if (month==2&&year%100==0&&year%400==0)
        cout<<"This month has 29 days"<<endl;
    else if (month==2&&year%100!=0&&year%4==0)
        cout<<"This month has 29 days"<<endl;
    else if (month==2)
        cout<<"This month has 28 days"<<endl;
    //Exit stage right!
    return 0;
}