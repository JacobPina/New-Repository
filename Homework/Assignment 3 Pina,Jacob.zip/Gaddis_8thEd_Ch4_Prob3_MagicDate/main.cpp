/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 16, 2017, 4:15 PM
  Purpose:  Tells the user if a date is magic
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int day,month,year;
    int magNum;//Magic Number
    
    //Input values
    cout<<"The date 06/10/60 is magic because when you multiply the month "
            "and day number you get the year number"<<endl<<endl;
    cout<<"Enter a date and this program will tell you if it is a magic date"
            <<endl<<endl;;
    cout<<"First enter a month in the form of a number i.e.(January = 1)"<<
            endl<<endl;;
    cin>>month;
    cout<<"Now enter the day as a number"<<endl;
    cin>>day;
    cout<<"And now enter the year as a two digit year i.e.(2017 = 17)"<<endl;
    cin>>year;
    
    
    //Process by mapping inputs to outputs
    magNum=day*month;
    
    //Output values
    if (magNum==year)
        cout<<"WOW!!! The date "<<month<<"/"<<day<<"/"<<year<<
                " is a magic date"<<endl;
    else if (magNum!=year)
        cout<<"Sorry "<<month<<"/"<<day<<"/"<<year<<
            " is not a magic date"<<endl;
   
    //Exit stage right!
    return 0;
}