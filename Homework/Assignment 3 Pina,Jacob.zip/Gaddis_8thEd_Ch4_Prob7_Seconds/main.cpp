/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 16, 2017, 5:20 PM
  Purpose:  This Program will ask for any number of seconds and will "
            "appropriately convert that number into minutes hours or days
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float seconds;
    float minutes,hours,days;
    
    //Input values
    cout<<"This Program will ask for any number of seconds and will "
            "appropriately convert that number into minutes hours or days"
            "depending on how big you go"<<endl;
    cout<<"Please enter any number of seconds"<<endl;
    cin>>seconds;
    
    
    
    //Process by mapping inputs to outputs
    minutes=seconds/60;
    hours=seconds/3600;
    days=seconds/86400;
        
    //Output values
    if (seconds<60)
        cout<<"This is just "<<seconds<<" seconds"<<endl;
    else if (seconds>60&&seconds<3600)
        cout<<"This is equal to "<<setprecision(4)<<minutes<<" minutes"<<endl;
    else if (seconds>3600&&seconds<86400)
        cout<<"This is equal to "<<setprecision(4)<<hours<<" hours"<<endl;
    else if (seconds>86400)
        cout<<"This is equal to "<<setprecision(4)<<days<<" days"<<endl;
    
    //Exit stage right!
    return 0;
}