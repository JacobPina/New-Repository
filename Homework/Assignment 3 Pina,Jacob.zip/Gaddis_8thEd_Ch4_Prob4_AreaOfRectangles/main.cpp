/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 16, 2017, 1:56 PM
  Purpose:  This program will compare the areas of 2 rectangles and determine
 *  which is bigger
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float len1,len2;//Length of rectangle 1 and 2
    float wid1,wid2;//Width of rectangle 1 and 2 
    float area1,area2;//Area of rectangle 1 and 2
    
    //Input values
    cout<<"This program will compare the areas of 2 rectangles and determine "
            "which is bigger and which is smaller"<<endl;
    cout<<"Please enter the length and width of rectangle 1 with a space "
            "between them"<<endl;
    cin>>len1>>wid1;
    
    area1=len1*wid1;
    
    cout<<"Please enter the length and width of rectangle 2 with a space "
            "between them"<<endl;
    cin>>len2>>wid2;
    
    area2=len2*wid2;
    
    //Process by mapping inputs to outputs
    
    
    //Output values
    if (area1>area2)
        cout<<"Rectangle 1 has an area of "<<area1<<" ft^2 which is larger than"
                "the are of rectangle 2 which is "<<area2<<" ft^2"<<endl;
    else if (area2>area1)
        cout<<"Rectangle 2 has an area of "<<area2<<" ft^2 which is larger than"
                "the are of rectangle 1 which is "<<area1<<" ft^2"<<endl;
    else if (area1==area2)
        cout<<"Rectangle 1 and Rectangle 2 both have the same area of "<<area1
                <<" ft^2"<<endl;
    
    //Exit stage right!
    return 0;
}