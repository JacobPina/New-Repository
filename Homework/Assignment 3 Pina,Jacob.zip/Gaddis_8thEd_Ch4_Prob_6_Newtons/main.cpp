/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 16, 2017, 5:15 PM
  Purpose:  This program calculates how many newtons(weight) an object has
 *  when you enter its mass in kilograms. This is on earth with gravity =9.8
 * Must be between 10 and 1000 newtons or else a message will say its too heavy
 * or light
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float weight,mass;//Weight in Newtons and mass in kilograms
    
    //Input values
    cout<<"This program calculates how many newtons(weight) an object has"
       "when you enter its mass in kilograms"<<endl;
    cout<<"Please enter the mass of an object in kilograms"<<endl;
    cin>>mass;
   
        
    //Process by mapping inputs to outputs
     weight=mass*9.8;
    
    //Output values
     if (weight>1000)
         cout<<"This object is over 1000 newtons and is too heavy"<<endl;
     else if (weight<1000&&weight>10)
         cout<<"The weight of this object is "<<weight<<" newtons"<<endl;
     else if (weight<10)
         cout<<"This object is under 10 newtons and is too light"<<endl;
    //Exit stage right!
    return 0;
}