/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 3, 2017, 12:15 PM
  Purpose: The user enters how many pennies nickels dimes and quarters they 
 * want to use to try to get 1 dollar. the program will tell them if they are 
 * over or under and by how much
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int nPenies,nNikels,nDimes,nQtrs;
    float penies,nickels,dimes,qtrs;
    float total;
    
    //Input values
    penies=.01;
    nickels=.05;
    dimes=.10;
    qtrs=.25;
    cout<<"Lets play a game where you enter how many pennies nickles dimes"
            "and quarters anre needed to make a dollar"<<endl;
    cout<<"How many pennies do you want to use"<<endl;
    cin>>nPenies;
    cout<<"How many nickels do you want to use"<<endl;
    cin>>nNikels;
    cout<<"How many dimes do you want to use"<<endl;
    cin>>nDimes;
    cout<<"How many quarters do you want to use"<<endl;
    cin>>nQtrs;
    
    
    //Process by mapping inputs to outputs
    total=(nPenies*penies)+(nNikels*nickels)+(nDimes*dimes)+(nQtrs*qtrs);
    
    //Output values
    if (total==1.00)
        cout<<"Congrats that many number of pennies, nickels, dimes, and "
                "quarters is equal to exactly 1 dollar"<<endl;
    else if (total>1.00)
        cout<<"Oops looks like you were over by "<<total-1.00<<endl;
    else if (total<1.00)
        cout<<"Oops looks like you were under by "<<1.00-total<<endl;
    //Exit stage right!
    return 0;
}