/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 3, 2017, 12:15 PM
  Purpose:  Given 3 Phone packages the program asks which you bought and
 * tells you your total bill 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float pkgA,pkgB,pkgC,min;
    char pkgBot;
    
    //Input values
    pkgA=39.99;
    pkgB=59.99;
    pkgC=69.99;
    
    cout<<"Package A cost $39.99/month w/ 450 minutes and every additional "
            "minute is $0.45"<<endl;
    cout<<"Package B cost $59.99/month w/ 900 minutes and every additional "
            "minute is $0.40"<<endl;
    cout<<"Package C cost $69.99/month w/ unlimited minutes"<<endl;
    cout<<"If you enter which package you bought by entering A,B,or C and then "
            "enter how many minutes you used this program will display "
            "your total bill"<<endl<<endl;
    cout<<"Which Package did you buy"<<endl;
    cin>>pkgBot;
    cout<<"How many minutes did you use?"<<endl;
    cin>>min;
    
    
    //Process by mapping inputs to outputs
    
    //Output values
    if (pkgBot==65&&min<450)
        cout<<"Your total is equal to $"<<pkgA<<endl;
    else if (pkgBot==65&&min>450)
        cout<<"Your total is equal to $"<<pkgA+(.45*(min-450))<<endl;
    else if (pkgBot==66&&min<900)
        cout<<"Your total is equal to $"<<pkgB<<endl;
    else if (pkgBot==66&&min>900)
        cout<<"Your total is equal to $"<<pkgB+(.40*(min-900))<<endl;
    else if (pkgBot==67&&min>=0)
        cout<<"Your total is equal to $"<<pkgC<<endl;
    //Exit stage right!
    return 0;
}