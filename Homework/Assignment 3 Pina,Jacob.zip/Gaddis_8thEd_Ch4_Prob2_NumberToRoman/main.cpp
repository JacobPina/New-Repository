/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 16, 2017, 1:15 PM
  Purpose:  This program will ask you to enter a number and it will translate it
 *  into a roman numeral (must be between 1 and 10)
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    int n1;
    
    //Input values
     cout<<"This program will change any number between 1 and 10 into a Roman "
            "numeral"<<endl;
    cout<<"Please enter a number between 1 and 10"<<endl;
    cin>>n1;
    
    //Process by mapping inputs to outputs
    
    //Output values
  
    if (n1>10)
        cout<<"Sorry this number is too big"<<endl;
    else if (n1==10)
        cout<<n1<<" is equal to X"<<endl;
    else if (n1==9)
        cout<<n1<<" is equal to IX"<<endl;
    else if (n1==8)
        cout<<n1<<" is equal to VIII"<<endl;
    else if (n1==7)
        cout<<n1<<" is equal to VII"<<endl;
    else if (n1==6)
        cout<<n1<<" is equal to VI"<<endl;
    else if (n1==5)
        cout<<n1<<" is equal to V"<<endl;
    else if (n1==4)
        cout<<n1<<" is equal to IV"<<endl;
    else if (n1==3)
        cout<<n1<<" is equal to III"<<endl;
    else if (n1==2)
        cout<<n1<<" is equal to II"<<endl;
    else if (n1==1)
        cout<<n1<<" is equal to I"<<endl;
    
    //Exit stage right!
    return 0;
}