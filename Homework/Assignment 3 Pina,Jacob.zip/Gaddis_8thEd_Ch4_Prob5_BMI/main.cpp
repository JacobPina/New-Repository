/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 16, 2017, 4:35 PM
  Purpose:  This program determines your BMI and tells you if you are 
 * underweight, overweight, or have an optimal body weight.
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    float BMI,height,weight;//Height in inches and weight in pounds
    
    //Input values
    cout<<"This program will determine your body mass index (BMI) and tell"
            "you if you are over weight, underweight, or optimal"<<endl<<endl;
    cout<<"But first we need some information from you first"<<endl<<endl;
    cout<<"Please enter your weight in pounds"<<endl<<endl;
    cin>>weight;
    cout<<"Please enter your height in inches"<<endl<<endl;
    cin>>height;
    
    //Process by mapping inputs to outputs
    BMI=weight*(703/(height*height));
    
    //Output values
    cout<<"An optimal BMI is between 18.5 and 25"<<endl;
    if (BMI>25)
        cout<<"It appears that your BMI is "<<BMI<<
                " meaning that you are overweight"<<endl;
    else if (BMI<25&&BMI>18.5)
        cout<<"Congrats!!! You have a BMI of "<<BMI<<
                " meaning you have an optimal weight"<<endl;
    else if (BMI<18.5)
        cout<<"It appears that your BMI is "<<BMI<<
                " meaning that you are underweight"<<endl;
            
    
    //Exit stage right!
    return 0;
}