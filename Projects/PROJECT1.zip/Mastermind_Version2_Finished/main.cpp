/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 30, 2017, 5:10 PM
  Purpose:  Menu to be used in PROJECT 1
 */

//System Libraries
#include <iostream>//Input Output Library
#include <string> //Random number generator seed
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to another

//Function Prototypes
string convert(unsigned short );

//Function Prototypes
void prob1();   //Tutorial
void prob2();   //The levels of Difficulty
void prob3();
void prob4();
void prob5();   //Secret Difficulty

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    char choice;    //Allows you to choose 
    
    //Loop on the menu
    do{
    
        //Input values
        cout<<"Choose from the list"<<endl;         //What the user sees 
        cout<<"Type 1 for the Tutorial"<<endl;
        cout<<"Type 2 for Easy Difficulty"<<endl;
        cout<<"Type 3 for Medium Difficulty"<<endl;
        cout<<"Type 4 for Hard Difficulty"<<endl;
        cout<<"IF YOU WANT TO EXIT HIT 0"<<endl;
        cin>>choice;

        //Switch to determine the Problem
        switch(choice){                 //Choice sends user to the level 
            case '1':{prob1();break;}       //of their choice
            case '2':{prob2();break;}
            case '3':{prob3();break;}
            case '4':{prob4();break;}
            case '5':{prob5();break;}   //Secret Level which user does not see
            default:                        //Until you beat HARD difficulty
                cout<<"You are exiting the Game"<<endl;
        }
    }while(choice>='1'&&choice<='5');
    
    //Exit stage right!
    return 0;
}
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem1 ***************************************
/* 
  File:   main.cppMIDTERM_PROBLEM_1
  Author: Jacob N. Piña
  Created on January 24, 2017, 12:15 PM
  Purpose:  This level is the tutorial, more in depth information can be found 
 *                          in the write up
 */
//******************************************************************************
void prob1(){
    cout<<"(: Welcome to the tutorial :)"<<endl;
 //Set Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned char num1;         //Actual number 
    unsigned int g1;            //Your guess
    
    //Input values
    num1=rand()%9+1;//[1,9]     //Random number created
    
    //Process by mapping inputs to outputs
    cout<<"In the tutorial you don't need to worry about how many "
            "turns you get"<<endl;
    cout<<"You will get as many turns as you need"<<endl;
    cout<<"But when you play a real game you will need to put in a"
            " certain amount of turns"<<endl<<endl;
    cout<<"This tutorial is meant to show you how the game works"<<endl;
    cout<<"Just follow the instructions given and you will do great"<<endl;
    cout<<"You win by guessing the right number "
            "the program is thinking of"<<endl<<endl;
    cout<<"This program is thinking of a random 1 digit number and you "
            "have to try to guess it"<<endl;
    
    for (int turns=1;turns<=1000000;turns++){
    cout<<"What do you think the number is?"<<endl;
    cin>>g1;                    //Guessing the number
    
    if(g1==num1){               //When you win
        cout<<"You got it right :)"<<endl;
        cout<<static_cast<int>(num1)<<" Was the right number"<<endl<<endl;
        cout<<"In a real game it will have more digits and when guessing"
                "numbers it will tell you how many"<<endl;
        cout<<" are right in the correct position and how many are right"
                " but in the wrong position"<<endl<<endl;
        break;
    }                           //If somehow you take this long it ends
        if (turns==1000000){
    cout<<"Sorry you ran out of turns :("<<endl;
    cout<<"You should play again, maybe with more turns"<<endl<<endl;
    }
    
    }
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem2 ***************************************
/* 
  File:   main.cpp EASY DIFFICULTY
  Author: Jacob N. Piña
  Created on January 30, 2017, 8:15 PM
  Purpose:  This is the easy difficulty 
 */
//******************************************************************************

void prob2(){
    cout<<"Welcome To Easy difficulty :)"<<endl;
    //Set Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned char num1,num2;        //Actual numbers
    unsigned int g1,g2;             //Guessing numbers
    unsigned int nTurns,cNumber=0,cPlace=0;//for the loop and tells you which
                                                //are right 
    
    //Input values
    num1=rand()%9+1;//[1,9]         //making the numbers
    num2=rand()%9+1;//[1,9]
    
    //Process by mapping inputs to outputs
    cout<<"This program is thinking of a random 2 digit number and you "
            "have to try to guess it"<<endl;
    //Decides how many turns you get
    cout<<"How many turns do you want to try to make it under?"<<endl;
    cin>>nTurns;
    
    //Loop depending on the turns you are allowed to use
    //Also guessing your numbers
    for (int turns=0;turns<nTurns;turns++){
    cout<<"What number do you think is in the first position?"<<endl;
    cin>>g1;
    cout<<"What number do you think is in the second position?"<<endl;
    cin>>g2;
    
    //Output values
      
    if (g1==num1){++cPlace;}    //Adds to right number and right place
    if (g2==num2){++cPlace;}
    if (num1==g2){cNumber++;}   //Adds to right number but wrong place
    if (num2==g1){cNumber++;}
    
    //When you get it right
    if(g1==num1&&g2==num2){
        cout<<"You got it right :)"<<endl;
        cout<<static_cast<int>(num1)<<static_cast<int>(num2)<<
                " Was the right number"<<endl<<endl;
        break;

    }
    //Lets the user knw which are right and which are wrong 
    cout<<"You got "<<cPlace<<" number(s) in the right position"<<endl;
    cout<<"And you got "<<cNumber<<" number(s) right but in the wrong "
            "position"<<endl;
    
    cPlace=0;//Resets the counters
    cNumber=0;
    
    //When you run out of turns
    if (turns==nTurns-1){
    cout<<"Sorry you ran out of turns :("<<endl;
    cout<<"You should play again, maybe with more turns"<<endl<<endl;
    }
    }
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem3 ***************************************
/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 25, 2017, 12:15 PM
  Purpose:  THIS IS THE MEDIUM DIFFICULTY
 */
//******************************************************************************

void prob3(){
    cout<<"Welcome To Medium difficulty :)"<<endl;
    //Set Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned char num1,num2,num3;           //Actual numbers
    unsigned int g1,g2,g3;                  //Guessing numbers
    unsigned int nTurns,cNumber=0,cPlace=0; //Loop, and right number counter
    
    //Input values
    num1=rand()%9+1;//[1,9]                 //Making the numbers
    num2=rand()%9+1;//[1,9]
    num3=rand()%9+1;//[1,9]
    
    //Process by mapping inputs to outputs
    cout<<"This program is thinking of a random 3 digit number and you "
            "have to try to guess it"<<endl;
    //Making the number of turns you want
    cout<<"How many turns do you want to try to make it under?"<<endl;
    cin>>nTurns;
    
    //Loop depending on the amount of turns you entered
    for (int turns=0;turns<nTurns;turns++){
    //Entering your guesses
    cout<<"What number do you think is in the first position?"<<endl;
    cin>>g1;
    cout<<"What number do you think is in the second position?"<<endl;
    cin>>g2;
    cout<<"What number do you think is in the third position?"<<endl;
    cin>>g3;
       
    //Output values
      
    if (g1==num1){++cPlace;}            //right number and correct place counter
    if (g2==num2){++cPlace;}
    if (g3==num3){++cPlace;}
    if (num1==g2||num1==g3){cNumber++;} //right number but wrong place counter
    if (num2==g1||num2==g3){cNumber++;}
    if (num3==g1||num3==g2){cNumber++;}
    
    //When you get it right
    if(g1==num1&&g2==num2&&g3==num3){
        cout<<"You got it right :)"<<endl;
        cout<<static_cast<int>(num1)<<static_cast<int>(num2)<<
                static_cast<int>(num3)<<" Was the right number"<<endl<<endl;
        break;

    }
    //Lets the user know how many are right and if the position is right too
    cout<<"You got "<<cPlace<<" number(s) in the right position"<<endl;
    cout<<"And you got "<<cNumber<<" number(s) right but in the wrong "
            "position"<<endl;
    
    cPlace=0;   //Resets the counters for next loop
    cNumber=0;
   
    //If you run out of turns
    if (turns==nTurns-1){
    cout<<"Sorry you ran out of turns :("<<endl;
    cout<<"You should play again, maybe with more turns"<<endl<<endl;
    }
    }
    
}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem4 ***************************************
/* 
  File:   main.cpp 
  Author: Jacob N. Piña
  Created on January 25, 2017, 1:15 PM
  Purpose:  Hard Difficulty
 */
//******************************************************************************
void prob4(){
    cout<<"Welcome to the HARD difficulty"<<endl;
    //Set Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned char num1,num2,num3,num4;         //Actual numbers
    unsigned int g1,g2,g3,g4;                  //Guessing numbers
    unsigned int nTurns,cNumber=0,cPlace=0;    //Loop number, counters
    
    //Input values
    num1=rand()%9+1;//[1,9] //Creates the numbers
    num2=rand()%9+1;//[1,9]
    num3=rand()%9+1;//[1,9]
    num4=rand()%9+1;//[1,9]
    
    //Process by mapping inputs to outputs
    cout<<"This program is thinking of a random 4 digit number and you "
            "have to try to guess it"<<endl;
    //Entering the amount of turns you want to make it under
    cout<<"How many turns do you want to try to make it under?"<<endl;
    cin>>nTurns;
    
    for (int turns=1;turns<=nTurns;turns++){
    //Guessing the numbers
    cout<<"What number do you think is in the first position?"<<endl;
    cin>>g1;
    cout<<"What number do you think is in the second position?"<<endl;
    cin>>g2;
    cout<<"What number do you think is in the third position?"<<endl;
    cin>>g3;
    cout<<"What number do you think is in the fourth position?"<<endl;
    cin>>g4;
       
    //Output values
      
    if (g1==num1){++cPlace;}    //Right number and right place counters
    if (g2==num2){++cPlace;}
    if (g3==num3){++cPlace;}
    if (g4==num4){++cPlace;}
    if (num1==g2||num1==g3||num1==g4){cNumber++;}//Right number but wrong 
    if (num2==g1||num2==g3||num2==g4){cNumber++;}   //wrong place number
    if (num3==g1||num3==g2||num3==g4){cNumber++;}
    if (num4==g1||num4==g2||num4==g3){cNumber++;}
    
    //When you get it right
    if(g1==num1&&g2==num2&&g3==num3&&g4==num4){
        cout<<"You got it right :)"<<endl;
        cout<<static_cast<int>(num1)<<static_cast<int>(num2)<<
                static_cast<int>(num3)<<static_cast<int>(num4)<<
                "Was the right number"<<endl<<endl;
        cout<<"BUT WAIT THERE IS MORE!!!!"<<endl;
        cout<<"IF YOU ENTER 5 WHEN CHOOSING THE LEVEL OF DIFFICULTY"<<endl;
        cout<<"YOU WIL GO TO THE SECRET DIFFICULTY "<<endl;
        break;

    }
    //Tells the user how many right and if their place was right
    cout<<"You got "<<cPlace<<" number(s) in the right position"<<endl;
    cout<<"And you got "<<cNumber<<" number(s) right but in the wrong "
            "position"<<endl<<endl;
    
    cPlace=0;   //Resets the counters for next loop
    cNumber=0;
    
    //If you lose
     if (turns==nTurns-1){
    cout<<"Sorry you ran out of turns :("<<endl;
    cout<<"You should play again, maybe with more turns"<<endl<<endl;
    }
    }

}

//000000000000000000000000000000000000000000000000000000000000000000000000000000
//000000000000000000000000000000000000000000000000000000000000000000000000000000
//***************************** Problem5 ***************************************
/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 25, 2017, 10:15 PM
  Purpose:  INSANE DIFFICULTY, SECRET LEVEL
 */
//******************************************************************************
void prob5(){
    //How you know you have entered the secret difficulty
    cout<<"You HAVE ENTERED INSANE DIFFICULTY"<<endl;
    cout<<"__________________________________"<<endl;
    //Set Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned char num1,num2,num3,num4,num5;//Actual numbers
    unsigned int g1,g2,g3,g4,g5;//Guessing numbers
    unsigned int nTurns,cNumber=0,cPlace=0;//For loop, counters
    
    //Input values
    num1=rand()%9+1;//[1,9] //Creates the numbers
    num2=rand()%9+1;//[1,9]
    num3=rand()%9+1;//[1,9]
    num4=rand()%9+1;//[1,9]
    num5=rand()%9+1;//[1,9]
    
    //Process by mapping inputs to outputs
    cout<<"This program is thinking of a random 5 digit number and you "
            "have to try to guess it"<<endl;
    //You dont get to decide how many turns you get in insane difficulty
    cout<<"This is INSANE DIFICULTY so you only get 10 turns"<<endl;
    cout<<"GOOD LUCK HAHA"<<endl;
    
    //Loop on 10 turns
    for (int turns=0;turns<=10;turns++){
    //Guessing the numbers
    cout<<"What number do you think is in the first position?"<<endl;
    cin>>g1;
    cout<<"What number do you think is in the second position?"<<endl;
    cin>>g2;
    cout<<"What number do you think is in the third position?"<<endl;
    cin>>g3;
    cout<<"What number do you think is in the fourth position?"<<endl;
    cin>>g4;
    cout<<"What number do you think is in the fifth position?"<<endl;
    cin>>g5;
       
    //Output values
      
    if (g1==num1){++cPlace;}//Right number and right place counter
    if (g2==num2){++cPlace;}
    if (g3==num3){++cPlace;}
    if (g4==num4){++cPlace;}
    if (g5==num5){++cPlace;}
    if (num1==g2||num1==g3||num1==g4||num1==g5){cNumber++;}//Right number but 
    if (num2==g1||num2==g3||num2==g4||num2==g5){cNumber++;} //wrong place 
    if (num3==g1||num3==g2||num3==g4||num3==g5){cNumber++;} //counter
    if (num4==g1||num4==g2||num4==g3||num4==g5){cNumber++;}
    if (num5==g1||num5==g2||num5==g3||num5==g4){cNumber++;}
    
    //If you win
    if(g1==num1&&g2==num2&g3==num3&&g4==num4&&g5==num5){
        cout<<"CONGRATS YOU BEAT THE GAME "<<endl;
        cout<<static_cast<int>(num1)<<static_cast<int>(num2)<<
                static_cast<int>(num3)<<static_cast<int>(num4)<<
                static_cast<int>(num5)<<"Was the right number"<<endl;
cout<<"*     *     *   *****    *    *    *    *  *****   ***     "<<endl;
cout<<"*    * *    *     *      **   *    **   *  *      *    *   "<<endl;
cout<<"**  *   *  **     *      * *  *    * *  *  *****  ****     "<<endl;
cout<<" * *     * *      *      *  * *    *  * *  *      *   *    "<<endl;
cout<<"  *       *     *****    *   **    *   **  *****  *    *   "<<endl<<endl;
break;

    }
    //Lets the user know how many numbers are right and how many are in the 
            //right place
    cout<<"You got "<<cPlace<<" number(s) in the right position"<<endl;
    cout<<"And you got "<<cNumber<<" number(s) right but in the wrong "
           "position"<<endl;
    
    cPlace=0;   //Resets the counters
    cNumber=0;
    
    //If you lose
    cout<<"You ran out of turns :("<<endl;
    cout<<"I knew only the smart ones could beat it"<<endl<<endl;
    
    }
    //Exit stage right!
}