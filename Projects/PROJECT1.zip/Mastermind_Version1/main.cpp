/* 
  File:   main.cpp
  Author: Jacob N. Piña
  Created on January 3, 2017, 12:15 PM
  Purpose:  Version 1
 */

//System Libraries
#include <iostream>

using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Set Random Number Seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    unsigned char num1,num2,num3,num4;
    unsigned int g1,g2,g3,g4;
    unsigned int nTurns,cNumber=0,cPlace=0;
    
    //Input values
    num1=rand()%9+1;//[1,9]
    num2=rand()%9+1;//[1,9]
    num3=rand()%9+1;//[1,9]
    num4=rand()%9+1;//[1,9]
    
    //Process by mapping inputs to outputs
    cout<<"This program is thinking of a random 4 digit number and you "
            "have to try to guess it"<<endl;
    cout<<"How many turns do you want to try to make it under?"<<endl;
    cin>>nTurns;
    
    for (int turns=1;turns<=nTurns;turns++){
    cout<<"What number do you think is in the first position?"<<endl;
    cin>>g1;
    cout<<"What number do you think is in the second position?"<<endl;
    cin>>g2;
    cout<<"What number do you think is in the third position?"<<endl;
    cin>>g3;
    cout<<"What number do you think is in the fourth position?"<<endl;
    cin>>g4;
       
    //Output values
      
    if (g1==num1){++cPlace;}
    if (g2==num2){++cPlace;}
    if (g3==num3){++cPlace;}
    if (g4==num4){++cPlace;}
    if (num1==g2||num1==g3||num1==g4){cNumber++;}
    if (num2==g1||num2==g3||num2==g4){cNumber++;}
    if (num3==g1||num3==g2||num3==g4){cNumber++;}
    if (num4==g1||num4==g2||num4==g3){cNumber++;}
    
    
    if(g1==num1&&g2==num2&g3==num3&&g4==num4){
        cout<<"You got it right :)"<<endl;
        cout<<static_cast<int>(num1)<<static_cast<int>(num2)<<
                static_cast<int>(num3)<<static_cast<int>(num4)<<
                "Was the right number"<<endl;
        return 0;
    }
    cout<<"You got "<<cPlace<<" number(s) in the right position"<<endl;
    cout<<"And you got "<<cNumber<<" number(s) right but in the wrong "
           "position"<<endl;
    
    cPlace=0;
    cNumber=0;
    
    }
    
    cout<<"Sorry you ran out of turns :("<<endl;
    cout<<"You should play again, maybe with more turns"<<endl;
    
    //Exit stage right!
    return 0;
}